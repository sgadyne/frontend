// Strict portable package declarations. These describe logical contracts, never installations.
import {validateWorkflowDefinition} from './workflow.mjs';

export const PREPARE_OPERATION = Object.freeze({id:'data.prepare.v1', revision:'sha256:012f1a6e8dd9954e734d6cb145154258be97a3111cf988c8404d32f477262871'});
const IDENTIFIER = /^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$/;
const SAFE_PATH = /^(?!\/)(?!.*(?:^|\/)\.{1,2}(?:\/|$))[A-Za-z0-9._~-]+(?:\/[A-Za-z0-9._~-]+)*$/;
export class PackageRequirementsError extends TypeError {
  constructor(message) { super(message); this.name='PackageRequirementsError'; this.code='INVALID_PACKAGE_REQUIREMENTS'; }
}
const fail = message => { throw new PackageRequirementsError(message); };
function fields(value, keys, label) {
  if (!value || typeof value !== 'object' || Array.isArray(value) || ![Object.prototype,null].includes(Object.getPrototypeOf(value)) || Object.getOwnPropertySymbols(value).length || Object.keys(value).length !== keys.length || keys.some(key => !Object.hasOwn(value,key)) || Object.values(Object.getOwnPropertyDescriptors(value)).some(d => !d.enumerable || !Object.hasOwn(d,'value'))) fail(`${label} has missing or unsupported fields`);
}
function id(value, label) { if (typeof value !== 'string' || !IDENTIFIER.test(value)) fail(`${label} must be a bounded logical identifier`); }
function boundedArray(value, limit) {
  return Array.isArray(value) && Object.getPrototypeOf(value) === Array.prototype && value.length <= limit &&
    !Object.getOwnPropertySymbols(value).length && Object.keys(value).length === value.length &&
    Object.getOwnPropertyNames(value).length === value.length + 1 &&
    Object.keys(value).every((key,index) => key === String(index)) &&
    Object.values(Object.getOwnPropertyDescriptors(value)).every(d => Object.hasOwn(d,'value'));
}
export function validatePackageReadRequirement(requirement) {
  fields(requirement,['applicationId','requirementId','access','contract','requiredCapabilities'],'read requirement');
  id(requirement.applicationId,'applicationId'); id(requirement.requirementId,'requirementId');
  if (requirement.access !== 'read') fail('read requirement cannot request execution');
  fields(requirement.contract,['id','version'],'payload contract'); id(requirement.contract.id,'contract id');
  if (!Number.isSafeInteger(requirement.contract.version) || requirement.contract.version < 1) fail('positive payload contract version required');
  const caps=requirement.requiredCapabilities;
  if (!boundedArray(caps,2) || caps.length < 1 ||
      caps.some(c => !['resolve','exactRead'].includes(c)) || !caps.includes('exactRead') || new Set(caps).size !== caps.length) fail('read capabilities require exactRead and optional resolve');
  return requirement;
}
export function validatePackageBackend(backend, assets) {
  const version=backend && typeof backend==='object' ? Object.getOwnPropertyDescriptor(backend,'schemaVersion')?.value : undefined;
  fields(backend,version===2?['schemaVersion','requirements','workflows','reads']:['schemaVersion','requirements','workflows'],'backend');
  if (![1,2].includes(version)) fail('unsupported backend schema version');
  if (!Array.isArray(backend.requirements) || backend.requirements.length > 200 || !Array.isArray(backend.workflows) || backend.workflows.length > 200) fail('backend arrays exceed limits');
  const requirements=new Set(), paths=new Set();
  for (const requirement of backend.requirements) {
    fields(requirement,['applicationId','requirementId','operation'],'requirement');
    id(requirement.applicationId,'applicationId'); id(requirement.requirementId,'requirementId');
    fields(requirement.operation,['id','revision'],'operation');
    if (requirement.operation.id !== PREPARE_OPERATION.id || requirement.operation.revision !== PREPARE_OPERATION.revision) fail('unsupported exact operation contract');
    const key=`${requirement.applicationId}\n${requirement.requirementId}`;
    if (requirements.has(key)) fail('duplicate or conflicting requirement');
    requirements.add(key);
  }
  if (version === 2) {
    if (!boundedArray(backend.reads,200)) fail('invalid read requirements');
    for (const read of backend.reads) {
      validatePackageReadRequirement(read);
      const key=`${read.applicationId}\n${read.requirementId}`;
      if (requirements.has(key)) fail('duplicate or conflicting requirement');
      requirements.add(key);
    }
  }
  const inventory = assets === undefined ? undefined : new Set(assets.map(asset=>asset.path));
  for (const workflow of backend.workflows) {
    fields(workflow,['path'],'workflow asset');
    if (typeof workflow.path !== 'string' || workflow.path.length > 240 || !SAFE_PATH.test(workflow.path) || !workflow.path.toLowerCase().endsWith('.json')) fail('workflow path must be safe JSON asset');
    if (paths.has(workflow.path)) fail('duplicate workflow asset');
    if (inventory && !inventory.has(workflow.path)) fail('workflow asset is not inventoried');
    paths.add(workflow.path);
  }
  return backend;
}
/** Validate a workflow against all exact declarations for its selected logical binding. */
export function validateDeclaredWorkflow(definition, backend) {
  validatePackageBackend(backend);
  validateWorkflowDefinition(definition);
  const requirementId=definition.bindings[definition.step.binding].requirementId;
  if (!backend.requirements.some(item => item.applicationId===definition.applicationId && item.requirementId===requirementId && item.operation.id===definition.step.operation.id && item.operation.revision===definition.step.operation.revision)) fail('workflow uses an undeclared requirement or operation');
  return definition;
}
/** Call only after asset size and digest have been checked. */
export function validatePackageWorkflowAssets(backend, assets) {
  validatePackageBackend(backend);
  if (!(assets instanceof Map)) fail('asset map required');
  for (const {path} of backend.workflows) {
    const bytes=assets.get(path);
    if (!(bytes instanceof Uint8Array) || bytes.byteLength > 65536) fail('workflow asset missing or too large');
    let definition;
    try { definition=JSON.parse(new TextDecoder('utf-8',{fatal:true}).decode(bytes)); } catch { fail('workflow asset must be valid UTF-8 JSON'); }
    validateDeclaredWorkflow(definition,backend);
  }
  return backend;
}
