import {randomUUID} from 'node:crypto';
import {hostname} from 'node:os';
import {constants} from 'node:fs';
import {lstat, mkdir, open, readdir, realpath, rename, rm} from 'node:fs/promises';
import path from 'node:path';
import {ExtensionValidationError} from './extension.mjs';

const STORE_BYTES = 8 * 1024 * 1024;
const RESTORE_MARKER = '.restore-in-progress';
const activeWriters = new Map();
const windowsDirectorySyncRoots = new Set();
// A commit with an unknown durability outcome requires a fresh process, not a new lease.
const fencedRoots = new Set();
function invalid(message, code = 'INVALID_STORAGE') { throw new ExtensionValidationError(message, code); }
function contains(root, filename) {
  const relative = path.relative(root, path.resolve(filename));
  return !relative || (relative !== '..' && !relative.startsWith(`..${path.sep}`) && !path.isAbsolute(relative));
}
function allowWindowsDirectorySyncFailure(error, filename) {
  return process.platform === 'win32' && error.code === 'EPERM' && [...windowsDirectorySyncRoots].some(root => contains(root, filename));
}
function assertWritable(filename) {
  for (const root of fencedRoots) if (contains(root, filename)) invalid('Storage authority is fenced after an uncertain commit. Stop and restart the runtime for recovery.', 'STORAGE_FENCED');
}
function fenceOwningWriters(filename) {
  for (const [root, state] of activeWriters) if (contains(root, filename)) { state.fenced = true; fencedRoots.add(root); }
}

async function assertNoRestoreMarker(root) {
  const marker = path.join(root, RESTORE_MARKER);
  try { await lstat(marker); }
  catch (error) {
    if (error.code === 'ENOENT') return;
    invalid('Could not inspect the runtime restore marker; stop and inspect this runtime before writing.', 'RESTORE_IN_PROGRESS');
  }
  invalid('A runtime restore is in progress or incomplete. Preserve the marker and inspect the runtime before writing.', 'RESTORE_IN_PROGRESS');
}

/** Read only a regular, bounded file. O_NOFOLLOW closes the final-component symlink race. */
export async function readJsonBounded(filename, {maxBytes = STORE_BYTES} = {}) {
  let handle;
  try {
    handle = await open(filename, constants.O_RDONLY | constants.O_NOFOLLOW);
    const info = await handle.stat();
    if (!info.isFile() || info.size > maxBytes) invalid('Stored JSON is not a bounded regular file.');
    if (await realpath(filename) !== path.resolve(filename)) invalid('Stored JSON paths cannot contain symbolic links.');
    // Read at most the bound even if a different writer modifies the file after stat.
    const buffer = Buffer.alloc(maxBytes + 1);
    let size = 0;
    while (size < buffer.length) {
      const {bytesRead} = await handle.read(buffer, size, buffer.length - size, null);
      if (!bytesRead) break;
      size += bytesRead;
    }
    if (size > maxBytes) invalid('Stored JSON exceeds its byte limit.');
    try { return JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(buffer.subarray(0, size))); }
    catch { invalid('Stored JSON is malformed; preserve the record for operator recovery.'); }
  } finally { await handle?.close(); }
}

/** Same-filesystem atomic replacement; file and parent-directory sync complete before return. */
export async function writeJsonAtomic(filename, value, {maxBytes = STORE_BYTES} = {}) {
  assertWritable(filename);
  const bytes = Buffer.from(`${JSON.stringify(value, null, 2)}\n`);
  if (bytes.length > maxBytes) invalid('Stored JSON exceeds its byte limit.');
  const directory = path.dirname(path.resolve(filename));
  await mkdir(directory, {recursive: true, mode: 0o700});
  if (await realpath(directory) !== directory) invalid('Storage directories cannot contain symbolic links.');
  const temporary = path.join(directory, `.${path.basename(filename)}.${process.pid}.${randomUUID()}.tmp`);
  let handle, published = false, renameAttempted = false;
  try {
    handle = await open(temporary, 'wx', 0o600);
    await handle.writeFile(bytes);
    await handle.sync();
    await handle.close();
    handle = undefined;
    assertWritable(filename);
    renameAttempted = true;
    await rename(temporary, filename);
    published = true;
    assertWritable(filename);
    const parent = await open(directory, 'r');
    try {
      try { await parent.sync(); }
      catch (error) { if (!allowWindowsDirectorySyncFailure(error, filename)) throw error; }
    } finally { await parent.close(); }
  } catch (error) {
    if (renameAttempted) fenceOwningWriters(filename);
    try { await handle?.close(); await rm(temporary, {force: true}); }
    catch (cleanupError) { error.cleanupError = cleanupError; }
    if (renameAttempted) {
      const uncertain = new ExtensionValidationError('Storage may have committed. The runtime is fenced until a fresh-process recovery.', 'STORAGE_COMMIT_UNKNOWN');
      uncertain.outcome = 'unknown'; uncertain.published = published; uncertain.cause = error;
      throw uncertain;
    }
    throw error;
  }
}

/** One native writer for the entire runtime, including operator CLI mutations. */
export async function acquireRuntimeWriter(runtimeDir, {allowPostgresAuthority = false, windowsDirectorySync = 'strict', windowsLoopbackDev = false} = {}) {
  if (!['strict', 'allow-eperm'].includes(windowsDirectorySync) || ((windowsLoopbackDev || windowsDirectorySync === 'allow-eperm') && (process.platform !== 'win32' || allowPostgresAuthority))) invalid('Windows directory-sync opt-in requires Windows file storage.', 'INVALID_CONFIG');
  await mkdir(path.resolve(runtimeDir), {recursive: true, mode: 0o700});
  const root = await realpath(runtimeDir);
  await assertNoRestoreMarker(root);
  if (!allowPostgresAuthority) {
    try { await lstat(path.join(root, 'postgres-authority.json')); invalid('This runtime is PostgreSQL-authoritative; use the configured server or offline metadata tools.', 'POSTGRES_AUTHORITY_REQUIRED'); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
  assertWritable(path.join(root, '.writer-lock', 'owner.json'));
  const lock = path.join(root, '.writer-lock');
  const token = randomUUID();
  const owner = {schemaVersion: 1, pid: process.pid, hostname: hostname(), token, createdAt: new Date().toISOString()};
  let acquired = false;
  for (let attempt = 0; attempt < 3 && !acquired; attempt++) {
    try { await mkdir(lock, {mode: 0o700}); acquired = true; }
    catch (error) {
      if (error.code !== 'EEXIST') throw error;
      let previous;
      try { previous = await readJsonBounded(path.join(lock, 'owner.json'), {maxBytes: 4096}); }
      catch { invalid('A runtime writer lock exists without a readable owner. Inspect it before recovery.', 'RUNTIME_LOCKED'); }
      if (previous.schemaVersion !== 1 || previous.hostname !== hostname() || !Number.isSafeInteger(previous.pid) || previous.pid < 1) {
        invalid('The runtime writer lock requires operator recovery.', 'RUNTIME_LOCKED');
      }
      let alive = true;
      try { process.kill(previous.pid, 0); }
      catch (probe) { if (probe.code === 'ESRCH') alive = false; }
      if (alive) invalid('Another process owns this runtime. Use its API or stop that writer first.', 'RUNTIME_LOCKED');
      // Claim recovery inside the lock before moving it. A contender rechecks the owner
      // after claiming, so it cannot move a newly acquired lock based on an old PID probe.
      let recovery;
      try { recovery = await open(path.join(lock, 'recovery'), 'wx', 0o600); }
      catch (claim) {
        if (claim.code === 'ENOENT') continue;
        if (claim.code === 'EEXIST') invalid('Runtime writer recovery is already in progress.', 'RUNTIME_LOCKED');
        throw claim;
      }
      await recovery.close();
      const checked = await readJsonBounded(path.join(lock, 'owner.json'), {maxBytes: 4096});
      if (checked.token !== previous.token || checked.pid !== previous.pid) {
        await rm(path.join(lock, 'recovery'), {force: true});
        invalid('Runtime writer changed during recovery; retry startup.', 'RUNTIME_LOCKED');
      }
      const stale = `${lock}.stale-${randomUUID()}`;
      try { await rename(lock, stale); }
      catch (move) { if (move.code === 'ENOENT') continue; throw move; }
      await rm(stale, {recursive: true});
    }
  }
  if (!acquired) invalid('Could not acquire the runtime writer lease.', 'RUNTIME_LOCKED');
  if (windowsLoopbackDev || windowsDirectorySync === 'allow-eperm') {
    windowsDirectorySyncRoots.add(root);
    console.warn('Sampo Windows file storage: directory sync EPERM is permitted for this runtime; rename crash durability is unavailable.');
  }
  try {
    // Recheck only after the exclusive lock directory is ours. A restore marker
    // created between the first check and lock claim must still fence this writer.
    await assertNoRestoreMarker(root);
  if (!allowPostgresAuthority) {
    try { await lstat(path.join(root, 'postgres-authority.json')); invalid('This runtime is PostgreSQL-authoritative; use the configured server or offline metadata tools.', 'POSTGRES_AUTHORITY_REQUIRED'); }
    catch (error) { if (error.code !== 'ENOENT') throw error; }
  }
    await writeJsonAtomic(path.join(lock, 'owner.json'), owner, {maxBytes: 4096});
  }
  catch (error) { windowsDirectorySyncRoots.delete(root); if (error.code === 'STORAGE_COMMIT_UNKNOWN') fencedRoots.add(root); await rm(lock, {recursive: true, force: true}); throw error; }
  const state = {held: true, fenced: false};
  activeWriters.set(root, state);
  let releasing;
  return Object.freeze({
    runtimeDir: root,
    assertHeld() {
      if (!state.held) invalid('The runtime writer lease is closed.', 'RUNTIME_LOCKED');
      if (state.fenced) invalid('Storage authority is fenced after an uncertain commit. Restart for recovery.', 'STORAGE_FENCED');
    },
    fence() {
      if (!state.held) invalid('The runtime writer lease is closed.', 'RUNTIME_LOCKED');
      state.fenced = true;
      fencedRoots.add(root);
    },
    async release() {
      if (!releasing) releasing = (async () => {
        if (!state.held) return;
        const current = await readJsonBounded(path.join(lock, 'owner.json'), {maxBytes: 4096});
        if (current.token !== token) invalid('Runtime writer ownership changed unexpectedly.', 'RUNTIME_LOCKED');
        state.held = false;
        activeWriters.delete(root);
        windowsDirectorySyncRoots.delete(root);
        await rm(lock, {recursive: true});
      })();
      return releasing;
    },
  });
}

/** No pending file is promoted without its record-specific intent. Orphans remain inspectable. */
export async function inspectPendingStoreFiles(directory) {
  try { return (await readdir(directory)).filter(name => name.startsWith('.') && name.endsWith('.tmp')).sort(); }
  catch (error) { if (error.code === 'ENOENT') return []; throw error; }
}
