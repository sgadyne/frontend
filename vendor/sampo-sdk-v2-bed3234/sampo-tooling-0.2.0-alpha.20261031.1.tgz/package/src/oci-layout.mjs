import {lstat, mkdir, readFile, rename, rm, stat, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {
  assertAssetBytes, EXTENSION_ARTIFACT_TYPE, EXTENSION_CONFIG_MEDIA_TYPE,
  MAX_EXTENSION_ASSET_SIZE, MAX_EXTENSION_ASSETS, OCI_CONFIG_MEDIA_TYPE, OCI_LAYER_MEDIA_TYPE, OCI_MANIFEST_MEDIA_TYPE,
  ExtensionValidationError, inspectExtensionDirectory, sha256, validateExtensionManifest,
} from './extension.mjs';

const LAYOUT_VERSION = '1.0.0';
const INDEX_MEDIA_TYPE = 'application/vnd.oci.image.index.v1+json';
const DIGEST_PATTERN = /^sha256:[a-f0-9]{64}$/;
const WINDOWS_RENAME_RETRY_CODES = new Set(['EPERM', 'EACCES', 'EBUSY']);
const WINDOWS_RENAME_RETRY_DELAYS_MS = [50, 100, 200, 400];

async function renameNewLayout(stageRoot, target) {
  for (let attempt = 0; ; attempt += 1) {
    try {
      await lstat(target);
      throw new ExtensionValidationError('OCI layout appeared while creating it.', 'LAYOUT_EXISTS');
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }

    try {
      await rename(stageRoot, target);
      return;
    } catch (error) {
      const delay = process.platform === 'win32' ? WINDOWS_RENAME_RETRY_DELAYS_MS[attempt] : undefined;
      if (!delay || !WINDOWS_RENAME_RETRY_CODES.has(error.code)) throw error;
      await new Promise(resolve => setTimeout(resolve, delay));
    }
  }
}

function descriptor(mediaType, bytes, annotations = {}) {
  return {mediaType, digest: `sha256:${sha256(bytes)}`, size: bytes.byteLength, ...(Object.keys(annotations).length ? {annotations} : {})};
}

async function atomicWrite(filename, bytes) {
  await mkdir(path.dirname(filename), {recursive: true});
  const temporary = `${filename}.${process.pid}.${Date.now()}.tmp`;
  await writeFile(temporary, bytes, {flag: 'wx'});
  try { await rename(temporary, filename); }
  catch (error) { await rm(temporary, {force: true}); throw error; }
}

async function writeBlob(layoutDir, bytes) {
  const digest = `sha256:${sha256(bytes)}`;
  const blobPath = path.join(layoutDir, 'blobs', 'sha256', digest.slice(7));
  try {
    const existing = await readFile(blobPath);
    if (!existing.equals(bytes)) throw new ExtensionValidationError(`Existing OCI blob '${digest}' does not match its digest.`, 'ASSET_INTEGRITY');
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    await mkdir(path.dirname(blobPath), {recursive: true});
    await atomicWrite(blobPath, bytes);
  }
  return {digest, size: bytes.byteLength};
}

async function readJsonBytes(filename, label) {
  let bytes;
  try { bytes = await readFile(filename); }
  catch (error) { throw new ExtensionValidationError(`Cannot read OCI ${label}: ${error.message}`, 'INVALID_OCI_LAYOUT'); }
  try { return {bytes, value: JSON.parse(bytes.toString('utf8'))}; }
  catch { throw new ExtensionValidationError(`OCI ${label} is not valid JSON.`, 'INVALID_OCI_LAYOUT'); }
}

async function loadLayout(layoutDir) {
  const marker = await readJsonBytes(path.join(layoutDir, 'oci-layout'), 'layout marker');
  if (marker.value.imageLayoutVersion !== LAYOUT_VERSION) throw new ExtensionValidationError('Unsupported OCI layout version.', 'INVALID_OCI_LAYOUT');
  const index = await readJsonBytes(path.join(layoutDir, 'index.json'), 'index');
  if (index.value.schemaVersion !== 2 || !Array.isArray(index.value.manifests)) throw new ExtensionValidationError('OCI index has an invalid schema.', 'INVALID_OCI_LAYOUT');
  return {indexBytes: index.bytes, index: index.value};
}

export async function packExtensionToOciLayout({sourceDir, layoutDir}) {
  const inspected = await inspectExtensionDirectory(sourceDir);
  const target = path.resolve(layoutDir);
  const source = path.resolve(sourceDir);
  if (target === source || target.startsWith(`${source}${path.sep}`) || source.startsWith(`${target}${path.sep}`)) {
    throw new ExtensionValidationError('Source package and OCI layout must be separate directories.');
  }
  let isNew = false;
  try { await stat(target); }
  catch (error) {
    if (error.code !== 'ENOENT') throw error;
    isNew = true;
  }
  if (!isNew) await loadLayout(target);
  const stageRoot = isNew ? `${target}.stage-${process.pid}-${Date.now()}` : target;
  if (isNew) await mkdir(stageRoot, {recursive: true});
  try {
    const configBytes = Buffer.from(JSON.stringify({
      mediaType: EXTENSION_CONFIG_MEDIA_TYPE,
      manifest: inspected.manifest,
    }));
    const configBlob = await writeBlob(stageRoot, configBytes);
    const layers = [];
    for (const [assetPath, bytes] of inspected.assets) {
      const layer = await writeBlob(stageRoot, bytes);
      layers.push({
        mediaType: OCI_LAYER_MEDIA_TYPE,
        digest: layer.digest,
        size: layer.size,
        annotations: {'org.opencontainers.image.title': assetPath},
      });
    }
    const artifact = {
      schemaVersion: 2,
      mediaType: OCI_MANIFEST_MEDIA_TYPE,
      artifactType: EXTENSION_ARTIFACT_TYPE,
      config: {mediaType: OCI_CONFIG_MEDIA_TYPE, digest: configBlob.digest, size: configBlob.size},
      layers,
    };
    const manifestBytes = Buffer.from(JSON.stringify(artifact));
    const manifestBlob = await writeBlob(stageRoot, manifestBytes);
    let index;
    if (isNew) {
      await writeFile(path.join(stageRoot, 'oci-layout'), JSON.stringify({imageLayoutVersion: LAYOUT_VERSION}));
      index = {schemaVersion: 2, mediaType: INDEX_MEDIA_TYPE, manifests: []};
    } else {
      index = (await loadLayout(target)).index;
      // Work in a temporary copy for first-time layouts only. Existing layouts
      // add immutable blobs before replacing the small index atomically.
    }
    const digest = manifestBlob.digest;
    if (index.manifests.some(entry => entry.digest === digest)) {
      throw new ExtensionValidationError(`Release '${digest}' is already present in the OCI layout.`, 'DUPLICATE_RELEASE');
    }
    const reference = `${inspected.manifest.id}-${inspected.manifest.version}`;
    index.manifests.push({
      mediaType: OCI_MANIFEST_MEDIA_TYPE,
      artifactType: EXTENSION_ARTIFACT_TYPE,
      digest,
      size: manifestBytes.byteLength,
      annotations: {'org.opencontainers.image.ref.name': reference},
    });
    const indexBytes = Buffer.from(JSON.stringify(index, null, 2));
    if (isNew) {
      await writeFile(path.join(stageRoot, 'index.json'), indexBytes);
      await renameNewLayout(stageRoot, target);
    } else {
      await atomicWrite(path.join(target, 'index.json'), indexBytes);
    }
    return {digest, reference, manifest: inspected.manifest, layoutDir: target};
  } catch (error) {
    if (isNew) await rm(stageRoot, {recursive: true, force: true});
    throw error;
  }
}

async function readBlob(layoutDir, digest, expectedSize, label, maxSize = MAX_EXTENSION_ASSET_SIZE) {
  if (typeof digest !== 'string' || !DIGEST_PATTERN.test(digest)) throw new ExtensionValidationError(`${label} has an invalid digest.`, 'INVALID_OCI_LAYOUT');
  if (!Number.isSafeInteger(expectedSize) || expectedSize < 0 || expectedSize > maxSize) throw new ExtensionValidationError(`${label} has an invalid size.`, 'INVALID_OCI_LAYOUT');
  let bytes;
  try { bytes = await readFile(path.join(layoutDir, 'blobs', 'sha256', digest.slice(7))); }
  catch { throw new ExtensionValidationError(`${label} blob '${digest}' is missing.`, 'ASSET_INTEGRITY'); }
  if (bytes.byteLength !== expectedSize || `sha256:${sha256(bytes)}` !== digest) {
    throw new ExtensionValidationError(`${label} blob '${digest}' failed size or digest verification.`, 'ASSET_INTEGRITY');
  }
  return bytes;
}

export async function readOciExtension(layoutDir, digest) {
  const {index} = await loadLayout(layoutDir);
  const descriptorEntry = index.manifests.find(entry => entry.digest === digest);
  if (!descriptorEntry) throw new ExtensionValidationError(`OCI release '${digest}' is not in the layout.`, 'RELEASE_NOT_FOUND');
  if (descriptorEntry.mediaType !== OCI_MANIFEST_MEDIA_TYPE || descriptorEntry.artifactType !== EXTENSION_ARTIFACT_TYPE) {
    throw new ExtensionValidationError('OCI descriptor is not a supported extension artifact.', 'INCOMPATIBLE_RUNTIME');
  }
  const manifestBytes = await readBlob(layoutDir, digest, descriptorEntry.size, 'OCI manifest', 2 * 1024 * 1024);
  let artifact;
  try { artifact = JSON.parse(manifestBytes.toString('utf8')); }
  catch { throw new ExtensionValidationError('OCI manifest is not valid JSON.', 'INVALID_OCI_LAYOUT'); }
  if (artifact.schemaVersion !== 2 || artifact.mediaType !== OCI_MANIFEST_MEDIA_TYPE || artifact.artifactType !== EXTENSION_ARTIFACT_TYPE) {
    throw new ExtensionValidationError('OCI manifest is not a supported extension artifact.', 'INCOMPATIBLE_RUNTIME');
  }
  if (!artifact.config || artifact.config.mediaType !== OCI_CONFIG_MEDIA_TYPE) throw new ExtensionValidationError('OCI extension config descriptor is invalid.', 'INVALID_OCI_LAYOUT');
  const configBytes = await readBlob(layoutDir, artifact.config.digest, artifact.config.size, 'OCI config', 5 * 1024 * 1024);
  let config;
  try { config = JSON.parse(configBytes.toString('utf8')); }
  catch { throw new ExtensionValidationError('OCI extension config is not valid JSON.', 'INVALID_OCI_LAYOUT'); }
  if (config.mediaType !== EXTENSION_CONFIG_MEDIA_TYPE) throw new ExtensionValidationError('OCI extension config media type is unsupported.', 'INVALID_OCI_LAYOUT');
  const {manifest, compatibility} = validateExtensionManifest(config.manifest, {allowIncompatibleRuntime: true});
  if (!Array.isArray(artifact.layers) || artifact.layers.length > MAX_EXTENSION_ASSETS) throw new ExtensionValidationError('OCI extension layers are invalid.', 'INVALID_OCI_LAYOUT');
  const assets = new Map();
  for (const layer of artifact.layers) {
    if (layer.mediaType !== OCI_LAYER_MEDIA_TYPE) throw new ExtensionValidationError('OCI extension layer media type is unsupported.', 'INVALID_OCI_LAYOUT');
    const assetPath = layer.annotations?.['org.opencontainers.image.title'];
    if (typeof assetPath !== 'string' || assets.has(assetPath)) throw new ExtensionValidationError('OCI extension layer path is missing or repeated.', 'UNSAFE_PATH');
    const expected = manifest.assets.find(asset => asset.path === assetPath);
    if (!expected || layer.size !== expected.size || layer.digest !== `sha256:${expected.sha256}`) {
      throw new ExtensionValidationError(`OCI extension layer '${assetPath}' does not match its manifest.`, 'ASSET_INTEGRITY');
    }
    const bytes = await readBlob(layoutDir, layer.digest, layer.size, `Extension asset '${assetPath}'`, MAX_EXTENSION_ASSET_SIZE);
    assets.set(assetPath, bytes);
  }
  const verifiedCompatibility = assertAssetBytes(manifest, assets, {allowIncompatibleRuntime: true});
  return {digest, manifest, compatibility: verifiedCompatibility ?? compatibility, ociManifestBytes: manifestBytes, ociConfigBytes: configBytes, artifact, assets};
}
