/** The v0 recipe is data, never an executable program. */
export const WORKFLOW_LIMITS = Object.freeze({bytes: 65536, parameters: 8, choices: 64, identifier: 128, title: 200});
export class WorkflowValidationError extends TypeError {
  constructor(path, message) { super(`Invalid workflow at ${path}: ${message}`); this.name = 'WorkflowValidationError'; this.path = path; this.code = 'INVALID_WORKFLOW'; }
}
const fail = (path, message) => { throw new WorkflowValidationError(path, message); };
function record(value, path, required, optional = []) {
  if (value === null || typeof value !== 'object' || Array.isArray(value) || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) fail(path, 'plain object required');
  const descriptors = Object.getOwnPropertyDescriptors(value);
  if (Object.getOwnPropertySymbols(value).length || Object.values(descriptors).some(d => !d.enumerable || !Object.hasOwn(d, 'value'))) fail(path, 'plain JSON properties required');
  const keys = Object.keys(descriptors);
  for (const key of keys) if (!required.includes(key) && !optional.includes(key)) fail(`${path}.${key}`, 'unknown field');
  for (const key of required) if (!Object.hasOwn(descriptors, key)) fail(`${path}.${key}`, 'required');
  return value;
}
const identifier = (v, path) => { if (typeof v !== 'string' || v.length > WORKFLOW_LIMITS.identifier || !/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(v)) fail(path, 'bounded logical identifier required'); };
function dictionary(value, path, max, min = 0) {
  if (value === null || typeof value !== 'object' || Array.isArray(value) || ![Object.prototype, null].includes(Object.getPrototypeOf(value))) fail(path, 'plain object required');
  const keys = Object.keys(value);
  record(value, path, keys);
  if (keys.length < min || keys.length > max) fail(path, `requires ${min} to ${max} entries`);
  for (const key of keys) identifier(key, `${path}.${key}`);
  return keys;
}
function strings(value, path) {
  if (!Array.isArray(value) || value.length < 1 || value.length > WORKFLOW_LIMITS.choices || Object.getPrototypeOf(value) !== Array.prototype || Object.getOwnPropertySymbols(value).length) fail(path, 'bounded nonempty array required');
  const descriptors = Object.getOwnPropertyDescriptors(value);
  if (Object.keys(descriptors).length !== value.length + 1) fail(path, 'dense JSON array required');
  for (let i = 0; i < value.length; i++) {
    const d = descriptors[String(i)];
    if (!d || !d.enumerable || !Object.hasOwn(d, 'value')) fail(path, 'dense JSON array required');
    identifier(d.value, `${path}[${i}]`);
  }
  if (new Set(value).size !== value.length) fail(path, 'duplicate choice');
}
/** Throws WorkflowValidationError for malformed or unsupported definitions. */
export function validateWorkflowDefinition(input) {
  const d = record(input, '$', ['schemaVersion', 'id', 'applicationId', 'title', 'parameters', 'bindings', 'step', 'output']);
  if (d.schemaVersion !== 1) fail('$.schemaVersion', 'unsupported version');
  identifier(d.id, '$.id'); identifier(d.applicationId, '$.applicationId');
  if (typeof d.title !== 'string' || d.title.length > WORKFLOW_LIMITS.title || !/^[\p{L}\p{N}][\p{L}\p{N} .,_()-]*$/u.test(d.title)) fail('$.title', 'bounded plain title required');
  const params = dictionary(d.parameters, '$.parameters', WORKFLOW_LIMITS.parameters);
  for (const key of params) {
    const p = record(d.parameters[key], `$.parameters.${key}`, ['type', 'enum'], ['default']);
    if (p.type !== 'string') fail(`$.parameters.${key}.type`, 'only string enums supported');
    strings(p.enum, `$.parameters.${key}.enum`);
    if (Object.hasOwn(p, 'default') && !p.enum.includes(p.default)) fail(`$.parameters.${key}.default`, 'must be an enum choice');
  }
  const bindings = dictionary(d.bindings, '$.bindings', 1, 1);
  for (const key of bindings) { const b = record(d.bindings[key], `$.bindings.${key}`, ['requirementId']); identifier(b.requirementId, `$.bindings.${key}.requirementId`); }
  const step = record(d.step, '$.step', ['kind', 'operation', 'binding', 'arguments']);
  if (step.kind !== 'invoke') fail('$.step.kind', 'only invoke supported');
  const op = record(step.operation, '$.step.operation', ['id', 'revision']);
  if (op.id !== 'data.prepare.v1') fail('$.step.operation.id', 'unsupported operation');
  if (typeof op.revision !== 'string' || !/^sha256:[0-9a-f]{64}$/.test(op.revision)) fail('$.step.operation.revision', 'exact lowercase sha256 required');
  if (typeof step.binding !== 'string' || !bindings.includes(step.binding)) fail('$.step.binding', 'unknown binding');
  const args = record(step.arguments, '$.step.arguments', ['partition']);
  const partition = record(args.partition, '$.step.arguments.partition', ['scenario']);
  if (typeof partition.scenario === 'string') identifier(partition.scenario, '$.step.arguments.partition.scenario');
  else { const ref = record(partition.scenario, '$.step.arguments.partition.scenario', ['parameter']); if (typeof ref.parameter !== 'string' || !params.includes(ref.parameter)) fail('$.step.arguments.partition.scenario.parameter', 'unknown parameter'); }
  const output = record(d.output, '$.output', ['kind', 'from']);
  if (output.kind !== 'publication' || output.from !== 'step.reference') fail('$.output', 'only step publication supported');
  if (new TextEncoder().encode(JSON.stringify(d)).length > WORKFLOW_LIMITS.bytes) fail('$', 'definition exceeds byte limit');
  return input;
}
/** Detached and deeply frozen: later caller mutations cannot change the recipe. */
export function defineWorkflow(input) {
  validateWorkflowDefinition(input);
  const copy = JSON.parse(JSON.stringify(input));
  const freeze = value => { if (value && typeof value === 'object') { for (const child of Object.values(value)) freeze(child); Object.freeze(value); } return value; };
  return freeze(copy);
}
