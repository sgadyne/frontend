import {inspectExtensionDirectory, REACT_VERSION, SUPPORTED_SDK_VERSIONS} from './extension.mjs';
import {readOciExtension} from './oci-layout.mjs';

function sourceOptions(source) {
  if (source === undefined) return;
  if (!source || typeof source !== 'object' || Array.isArray(source)
      || Object.keys(source).some(key => !['namespacePrefix', 'publisher'].includes(key))
      || typeof source.namespacePrefix !== 'string' || !source.namespacePrefix || source.namespacePrefix.length > 120
      || typeof source.publisher !== 'string' || !source.publisher || source.publisher.length > 200) {
    throw new TypeError('Authoring source hints require only a bounded namespacePrefix and publisher.');
  }
}

function reportFor(release, {source} = {}) {
  sourceOptions(source);
  const {manifest} = release;
  const diagnostics = [];
  const issue = (code, path, message, action) => diagnostics.push({severity: 'error', code, path, message, action});
  const cohort = manifest.runtime.sdk;
  const expectedPeers = {react: REACT_VERSION, 'react-dom': REACT_VERSION, '@sampo/contracts': cohort, '@sampo/sdk-react': cohort};
  const peers = manifest.runtime.peers;
  if (!SUPPORTED_SDK_VERSIONS.includes(cohort) || !peers || Object.keys(peers).length !== Object.keys(expectedPeers).length || Object.entries(expectedPeers).some(([name, version]) => peers[name] !== version)) {
    issue('INCOMPATIBLE_PEERS', 'runtime.peers', 'The declared host peers are missing, mixed, or outside the exact supported cohort.',
      `Declare React/React DOM ${REACT_VERSION}, contracts ${cohort}, and sdk-react ${cohort} together for runtime.sdk ${manifest.runtime.sdk}; do not mix legacy and alpha packages.`);
  }
  for (const [index, contribution] of manifest.contributions.entries()) {
    if (!contribution.id.startsWith(`${manifest.id}.`)) {
      issue('CONTRIBUTION_SCOPE_MISMATCH', `contributions[${index}].id`,
        `Contribution ${contribution.id} is outside the complete extension namespace ${manifest.id}.`,
        `Use ${manifest.id}.<name> in both the manifest and runtime widget definition, then rebuild and repack.`);
    }
  }
  for (const name of ['LICENSE', 'NOTICE']) {
    const legal = manifest.assets.filter(asset => asset.path === name || new RegExp(`^licenses/${name}(?:[._-][A-Za-z0-9._~-]+)?$`).test(asset.path));
    if (!legal.length || legal.some(asset => asset.size === 0)) {
      issue('LICENSE_INVENTORY_REQUIRED', `assets.${name}`, `Managed release review requires an inventoried nonempty ${name}.`,
        `Copy ${name} into the package before generating its SHA-256 asset inventory.`);
    }
  }
  if (source && (!manifest.id.startsWith(source.namespacePrefix) || manifest.publisher !== source.publisher)) {
    issue('PUBLISHER_SCOPE_MISMATCH', 'id,publisher', 'The extension identity or publisher differs from the supplied source hints.',
      'Use the operator-approved namespace and exact publisher; a source hint does not configure or authorize a registry.');
  }
  return {
    schemaVersion: 1,
    status: diagnostics.length ? 'attention-required' : 'ready-for-review',
    verification: 'manifest-and-inventoried-bytes-verified',
    admission: 'not-performed',
    installation: 'not-performed',
    ...(release.digest ? {digest: release.digest} : {}),
    extension: {id: manifest.id, version: manifest.version, publisher: manifest.publisher, license: manifest.license},
    runtime: manifest.runtime,
    entry: manifest.entry,
    contributions: manifest.contributions.map(({id, kind, title, export: exported, inputPorts, outputPorts, presentation}) => ({
      id, kind, title, export: exported,
      ...(inputPorts ? {inputPorts} : {}), ...(outputPorts ? {outputPorts} : {}),
      ...(presentation ? {presentation} : {}),
    })),
    inventory: manifest.assets.map(({path, size, sha256}) => ({path, size, sha256})),
    ...(manifest.backend ? {backend: manifest.backend} : {}),
    diagnostics,
    next: 'Stage the exact digest through the configured server, review its current admission, then approve and install explicitly. Runtime export resolution and current authority remain host/server checks.',
  };
}

/** Read-only author diagnostics. Never imports entry code, calls a registry, approves or installs. */
export async function inspectAuthoringDirectory(sourceDir, options) {
  sourceOptions(options?.source);
  return reportFor(await inspectExtensionDirectory(sourceDir), options);
}

/** Verify an exact local OCI layout and explain common authoring mistakes before managed review. */
export async function inspectAuthoringRelease(layoutDir, digest, options) {
  sourceOptions(options?.source);
  return reportFor(await readOciExtension(layoutDir, digest), options);
}
