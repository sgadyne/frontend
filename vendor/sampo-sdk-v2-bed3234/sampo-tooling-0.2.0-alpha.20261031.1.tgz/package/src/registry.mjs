import {spawn} from 'node:child_process';
import path from 'node:path';
import {ExtensionValidationError} from './extension.mjs';

function run(executable, args, {cwd} = {}) {
  return new Promise((resolve, reject) => {
    const child = spawn(executable, args, {cwd, windowsHide: true, stdio: ['ignore', 'pipe', 'pipe']});
    let stdout = '';
    let stderr = '';
    let overflow = false;
    const collect = (target, chunk) => {
      if (target.length + chunk.length > 1024 * 1024) { overflow = true; return target; }
      return target + chunk.toString('utf8');
    };
    child.stdout.on('data', chunk => { stdout = collect(stdout, chunk); });
    child.stderr.on('data', chunk => { stderr = collect(stderr, chunk); });
    child.once('error', error => {
      if (error.code === 'ENOENT') reject(new ExtensionValidationError('ORAS is not installed or is not available on PATH.', 'ORAS_NOT_INSTALLED'));
      else reject(error);
    });
    child.once('close', code => {
      if (overflow) return reject(new ExtensionValidationError('ORAS output exceeded the 1 MiB limit.', 'ORAS_OUTPUT_LIMIT'));
      if (code !== 0) return reject(new ExtensionValidationError(`ORAS exited with code ${code}: ${stderr.trim() || stdout.trim()}`, 'ORAS_FAILED'));
      resolve({stdout: stdout.trim(), stderr: stderr.trim()});
    });
  });
}

/**
 * Optional registry adapter. Authentication stays in ORAS' own credential
 * store; this process never accepts or forwards registry credentials.
 * Calls are deliberately separate from the API's OCI-layout/cache path.
 */
export function createOrasRegistryTransport({executable = process.env.ORAS_BIN ?? 'oras'} = {}) {
  return Object.freeze({
    kind: 'oci-registry-http-via-oras',
    async pushLayout({layoutDir, layoutReference, registryReference}) {
      if (!layoutReference || !registryReference) throw new ExtensionValidationError('Both OCI layout and registry references are required.');
      const source = `${path.resolve(layoutDir)}:${layoutReference}`;
      const result = await run(executable, ['cp', '--from-oci-layout', source, registryReference]);
      const digest = result.stdout.match(/(?:Digest:\s*)?(sha256:[a-f0-9]{64})/i)?.[1];
      return {registryReference, digest, output: result.stdout};
    },
    async pullToLayout({registryReference, layoutDir, layoutReference}) {
      if (!layoutReference || !registryReference) throw new ExtensionValidationError('Both registry and OCI layout references are required.');
      const target = `${path.resolve(layoutDir)}:${layoutReference}`;
      const result = await run(executable, ['cp', '--to-oci-layout', registryReference, target]);
      const digest = result.stdout.match(/(?:Digest:\s*)?(sha256:[a-f0-9]{64})/i)?.[1];
      return {registryReference, layoutDir: path.resolve(layoutDir), layoutReference, digest, output: result.stdout};
    },
  });
}
