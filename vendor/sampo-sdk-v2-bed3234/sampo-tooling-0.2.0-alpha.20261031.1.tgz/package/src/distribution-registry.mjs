import {randomBytes} from 'node:crypto';
import {mkdir, readFile, lstat, rename, rm, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {
  assertAssetBytes, EXTENSION_ARTIFACT_TYPE, EXTENSION_CONFIG_MEDIA_TYPE,
  MAX_EXTENSION_ASSET_SIZE, MAX_EXTENSION_ASSETS, MAX_EXTENSION_TOTAL_SIZE,
  OCI_CONFIG_MEDIA_TYPE, OCI_LAYER_MEDIA_TYPE, OCI_MANIFEST_MEDIA_TYPE,
  ExtensionValidationError, isSafeAssetPath, sha256, validateExtensionManifest,
} from './extension.mjs';
import {readOciExtension} from './oci-layout.mjs';

const OCI_LAYOUT_VERSION = '1.0.0';
const OCI_INDEX_MEDIA_TYPE = 'application/vnd.oci.image.index.v1+json';
const MANIFEST_LIMIT = 2 * 1024 * 1024;
const CONFIG_LIMIT = 5 * 1024 * 1024;
const DIGEST_RE = /^sha256:[a-f0-9]{64}$/;
const TAG_RE = /^[A-Za-z0-9_][A-Za-z0-9._-]{0,127}$/;
const LOOPBACK = new Set(['localhost', '127.0.0.1', '::1']);

function fail(message, code = 'REGISTRY_PROTOCOL') {
  throw new ExtensionValidationError(message, code);
}

function isLoopback(hostname) {
  return LOOPBACK.has(hostname.toLowerCase().replace(/^\[|\]$/g, ''));
}

function normalizeRegistryUrl(value, allowLoopbackHttp) {
  let url;
  try { url = new URL(value); }
  catch { fail('Registry URL must be an absolute HTTP(S) URL.', 'INVALID_REGISTRY_URL'); }
  if (!['http:', 'https:'].includes(url.protocol) || url.username || url.password || url.search || url.hash) {
    fail('Registry URL must not contain credentials, query or fragment.', 'INVALID_REGISTRY_URL');
  }
  if (url.protocol === 'http:' && (!allowLoopbackHttp || !isLoopback(url.hostname))) {
    fail('HTTP registry transport requires explicit permission and a loopback host.', 'INSECURE_REGISTRY_URL');
  }
  const pathPrefix = url.pathname.replace(/\/+$/, '');
  if (pathPrefix && pathPrefix.split('/').slice(1).some(segment => !/^[A-Za-z0-9._~-]+$/.test(segment) || segment === '.' || segment === '..')) {
    fail('Registry URL path prefix is invalid.', 'INVALID_REGISTRY_URL');
  }
  url.pathname = pathPrefix || '/';
  return {origin: url.origin, pathPrefix};
}

function validateRepository(repository) {
  if (typeof repository !== 'string' || repository.length > 255) fail('OCI repository name is invalid.', 'INVALID_REPOSITORY');
  const parts = repository.split('/');
  if (parts.length === 0 || parts.some(part => !/^[a-z0-9]+(?:[._-][a-z0-9]+)*$/.test(part))) {
    fail('OCI repository must use lowercase path components.', 'INVALID_REPOSITORY');
  }
  return parts.join('/');
}

function validateReference(reference) {
  if (typeof reference !== 'string') fail('OCI reference must be a tag or SHA-256 digest.', 'INVALID_REFERENCE');
  if (DIGEST_RE.test(reference)) return {kind: 'digest', value: reference};
  if (TAG_RE.test(reference)) return {kind: 'tag', value: reference};
  fail('OCI reference must be a safe tag or SHA-256 digest.', 'INVALID_REFERENCE');
}

function validateAuthorization(value) {
  if (value === undefined) return undefined;
  if (typeof value !== 'string' || !/^(?:Bearer|Basic) [A-Za-z0-9._~+/-]+=*$/i.test(value)) {
    fail('Registry authorization must be a single Bearer or Basic header value.', 'INVALID_REGISTRY_AUTH');
  }
  return value;
}

function descriptor(mediaType, bytes) {
  return {mediaType, digest: `sha256:${sha256(bytes)}`, size: bytes.byteLength};
}

function cancelBody(response) {
  try { void response.body?.cancel().catch(() => {}); } catch {}
}

function repositoryPath(basePath, repository) {
  return `${basePath}/v2/${repository}`;
}

async function readResponseBytes(response, maxSize, expectedSize, label) {
  const rawLength = response.headers.get('content-length');
  if (rawLength !== null) {
    const contentLength = Number(rawLength);
    if (!Number.isSafeInteger(contentLength) || contentLength < 0 || contentLength > maxSize || (expectedSize !== undefined && contentLength !== expectedSize)) {
      try { void response.body?.cancel().catch(() => {}); } catch {}
      fail(`${label} response has an invalid Content-Length.`, 'REGISTRY_CONTENT_LENGTH');
    }
  }
  if (!response.body) {
    if (expectedSize !== undefined && expectedSize !== 0) fail(`${label} response body is missing.`, 'REGISTRY_TRUNCATED');
    return Buffer.alloc(0);
  }
  const reader = response.body.getReader();
  const chunks = [];
  let total = 0;
  try {
    while (true) {
      const {done, value} = await reader.read();
      if (done) break;
      total += value.byteLength;
      if (total > maxSize || (expectedSize !== undefined && total > expectedSize)) {
        void reader.cancel().catch(() => {});
        fail(`${label} response exceeds its declared size limit.`, 'REGISTRY_SIZE_LIMIT');
      }
      chunks.push(Buffer.from(value));
    }
  } finally {
    reader.releaseLock();
  }
  if (expectedSize !== undefined && total !== expectedSize) fail(`${label} response is truncated or has the wrong size.`, 'REGISTRY_TRUNCATED');
  return Buffer.concat(chunks, total);
}

async function writeAtomic(filename, bytes) {
  await mkdir(path.dirname(filename), {recursive: true});
  const temporary = `${filename}.${process.pid}.${randomBytes(6).toString('hex')}.tmp`;
  await writeFile(temporary, bytes, {flag: 'wx'});
  try { await rename(temporary, filename); }
  catch (error) { await rm(temporary, {force: true}); throw error; }
}

async function writeBlob(layoutDir, bytes) {
  const digest = `sha256:${sha256(bytes)}`;
  const filename = path.join(layoutDir, 'blobs', 'sha256', digest.slice(7));
  try {
    const existing = await readFile(filename);
    if (!existing.equals(bytes)) fail(`Existing local OCI blob '${digest}' is corrupt.`, 'ASSET_INTEGRITY');
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
    await writeAtomic(filename, bytes);
  }
  return descriptor('application/octet-stream', bytes);
}

async function writeNewLayout(layoutDir, digest, manifestBytes, artifact, configBytes, assets, layoutReference) {
  await mkdir(layoutDir, {recursive: true});
  await writeFile(path.join(layoutDir, 'oci-layout'), JSON.stringify({imageLayoutVersion: OCI_LAYOUT_VERSION}));
  await writeBlob(layoutDir, configBytes);
  for (const bytes of assets.values()) await writeBlob(layoutDir, bytes);
  const manifest = Buffer.from(manifestBytes);
  const root = await writeBlob(layoutDir, manifest);
  if (root.digest !== digest) fail('Downloaded OCI manifest digest changed while staging.', 'REGISTRY_DIGEST_MISMATCH');
  const reconstructed = JSON.parse(manifest.toString('utf8'));
  if (JSON.stringify(reconstructed) !== JSON.stringify(artifact)) fail('Downloaded OCI manifest changed while staging.', 'REGISTRY_DIGEST_MISMATCH');
  const index = {
    schemaVersion: 2,
    mediaType: OCI_INDEX_MEDIA_TYPE,
    manifests: [{
      mediaType: OCI_MANIFEST_MEDIA_TYPE,
      artifactType: EXTENSION_ARTIFACT_TYPE,
      digest,
      size: manifest.byteLength,
      annotations: {'org.opencontainers.image.ref.name': layoutReference},
    }],
  };
  await writeFile(path.join(layoutDir, 'index.json'), JSON.stringify(index, null, 2));
}

async function readLayoutIndex(layoutDir) {
  let marker;
  let index;
  try {
    marker = JSON.parse(await readFile(path.join(layoutDir, 'oci-layout'), 'utf8'));
    index = JSON.parse(await readFile(path.join(layoutDir, 'index.json'), 'utf8'));
  } catch (error) {
    fail(`Target path is not a valid OCI layout: ${error.message}`, 'INVALID_OCI_LAYOUT');
  }
  if (marker.imageLayoutVersion !== OCI_LAYOUT_VERSION || index.schemaVersion !== 2 || !Array.isArray(index.manifests)) {
    fail('Target OCI layout has an unsupported structure.', 'INVALID_OCI_LAYOUT');
  }
  return index;
}

async function addVerifiedLayout({stageDir, targetDir, digest, layoutReference, manifestBytes, configBytes, assets}) {
  let targetStat;
  try { targetStat = await lstat(targetDir); }
  catch (error) { if (error.code !== 'ENOENT') throw error; }
  if (!targetStat) {
    await mkdir(path.dirname(targetDir), {recursive: true});
    await rename(stageDir, targetDir);
    return;
  }
  if (targetStat.isSymbolicLink() || !targetStat.isDirectory()) fail('Target OCI layout must be a regular directory.', 'INVALID_OCI_LAYOUT');
  const index = await readLayoutIndex(targetDir);
  const sameDigest = index.manifests.find(item => item.digest === digest);
  if (sameDigest) {
    const existing = await readOciExtension(targetDir, digest);
    if (!existing.ociManifestBytes.equals(manifestBytes)) fail('Existing OCI release does not match the pulled digest.', 'ASSET_INTEGRITY');
    return;
  }
  if (index.manifests.some(item => item.annotations?.['org.opencontainers.image.ref.name'] === layoutReference)) {
    fail(`OCI layout reference '${layoutReference}' already points to another release.`, 'DUPLICATE_REFERENCE');
  }
  await writeBlob(targetDir, configBytes);
  for (const bytes of assets.values()) await writeBlob(targetDir, bytes);
  const manifestBlob = await writeBlob(targetDir, manifestBytes);
  if (manifestBlob.digest !== digest) fail('Manifest digest changed while merging into the OCI layout.', 'REGISTRY_DIGEST_MISMATCH');
  index.manifests.push({
    mediaType: OCI_MANIFEST_MEDIA_TYPE,
    artifactType: EXTENSION_ARTIFACT_TYPE,
    digest,
    size: manifestBytes.byteLength,
    annotations: {'org.opencontainers.image.ref.name': layoutReference},
  });
  await writeAtomic(path.join(targetDir, 'index.json'), Buffer.from(JSON.stringify(index, null, 2)));
}

function createReleaseRegistryTransport({registryUrl, authorization, allowLoopbackHttp = false, fetchImpl = globalThis.fetch, timeoutMs = 30000} = {}) {
  if (typeof fetchImpl !== 'function') fail('A Fetch API implementation is required.', 'FETCH_UNAVAILABLE');
  const normalized = normalizeRegistryUrl(registryUrl, allowLoopbackHttp);
  const auth = validateAuthorization(authorization);

  function endpoint(pathname) {
    return new URL(`${normalized.pathPrefix}${pathname}`, normalized.origin);
  }

  async function request(url, method, extra = {}) {
    if (url.origin !== normalized.origin) fail('Registry request URL changed origin.', 'CROSS_ORIGIN_REGISTRY_URL');
    let response;
    try {
      response = await fetchImpl(url, {
        ...extra,
        method,
        redirect: 'manual',
        signal: AbortSignal.timeout(timeoutMs),
        headers: {
          ...(auth ? {Authorization: auth} : {}),
          ...(extra.headers ?? {}),
        },
      });
    } catch {
      fail(`Registry ${method} request failed for ${url.pathname}.`, 'REGISTRY_CONNECTION');
    }
    if (response.status >= 300 && response.status < 400) {
      cancelBody(response);
      fail(`Registry ${method} request returned a redirect; redirects are not followed.`, 'REGISTRY_REDIRECT');
    }
    return response;
  }

  async function requireV2(repository) {
    const response = await request(endpoint('/v2/'), 'GET');
    if (response.status !== 200) { cancelBody(response); fail(`Registry v2 endpoint returned HTTP ${response.status}.`, 'REGISTRY_HTTP'); }
    await readResponseBytes(response, 64 * 1024, undefined, 'Registry v2 response');
  }

  function blobUrl(repository, digest) {
    return endpoint(`${repositoryPath(normalized.pathPrefix, repository).slice(normalized.pathPrefix.length)}/blobs/${digest}`);
  }

  function manifestUrl(repository, reference) {
    return endpoint(`${repositoryPath(normalized.pathPrefix, repository).slice(normalized.pathPrefix.length)}/manifests/${reference}`);
  }

  async function verifyRemoteBlob(repository, digest, expectedSize) {
    const response = await request(blobUrl(repository, digest), 'GET');
    if (response.status !== 200) { cancelBody(response); fail(`Registry blob GET returned HTTP ${response.status}.`, 'REGISTRY_HTTP'); }
    const bytes = await readResponseBytes(response, MAX_EXTENSION_ASSET_SIZE, expectedSize, 'Registry blob');
    if (`sha256:${sha256(bytes)}` !== digest) fail(`Registry blob '${digest}' failed digest verification.`, 'REGISTRY_DIGEST_MISMATCH');
    return bytes;
  }

  async function uploadBlob(repository, digest, bytes) {
    const base = repositoryPath(normalized.pathPrefix, repository);
    const start = await request(endpoint(`${base.slice(normalized.pathPrefix.length)}/blobs/uploads/`), 'POST');
    if (start.status !== 202) { cancelBody(start); fail(`Registry upload start returned HTTP ${start.status}.`, 'REGISTRY_HTTP'); }
    const locationValue = start.headers.get('location');
    if (!locationValue) fail('Registry upload start did not return a Location.', 'REGISTRY_PROTOCOL');
    await readResponseBytes(start, 64 * 1024, undefined, 'Registry upload response');
    let location;
    try { location = new URL(locationValue, endpoint(`${base.slice(normalized.pathPrefix.length)}/blobs/uploads/`)); }
    catch { fail('Registry returned an invalid upload Location.', 'REGISTRY_PROTOCOL'); }
    const expectedPath = `${base}/blobs/uploads/`;
    if (location.origin !== normalized.origin || location.username || location.password || location.hash || !location.pathname.startsWith(expectedPath)) {
      fail('Registry upload Location must remain within the configured repository and origin.', 'CROSS_ORIGIN_REGISTRY_URL');
    }
    location.searchParams.set('digest', digest);
    const committed = await request(location, 'PUT', {
      headers: {'Content-Type': 'application/octet-stream', 'Content-Length': String(bytes.byteLength)},
      body: bytes,
      duplex: 'half',
    });
    if (committed.status !== 201) { cancelBody(committed); fail(`Registry blob commit returned HTTP ${committed.status}.`, 'REGISTRY_HTTP'); }
    const returnedDigest = committed.headers.get('docker-content-digest');
    if (returnedDigest !== digest) fail('Registry blob commit returned the wrong digest.', 'REGISTRY_DIGEST_MISMATCH');
    await readResponseBytes(committed, 64 * 1024, undefined, 'Registry blob commit response');
  }

  async function ensureBlob(repository, digest, bytes) {
    if (!DIGEST_RE.test(digest) || `sha256:${sha256(bytes)}` !== digest) fail('Local OCI blob does not match its descriptor.', 'ASSET_INTEGRITY');
    const head = await request(blobUrl(repository, digest), 'HEAD');
    if (head.status === 200) {
      const reportedDigest = head.headers.get('docker-content-digest');
      const length = head.headers.get('content-length');
      if ((reportedDigest && reportedDigest !== digest) || (length !== null && Number(length) !== bytes.byteLength)) {
        fail('Existing registry blob descriptor does not match the local content.', 'REGISTRY_DIGEST_MISMATCH');
      }
      await verifyRemoteBlob(repository, digest, bytes.byteLength);
      return;
    }
    if (head.status !== 404) { cancelBody(head); fail(`Registry blob HEAD returned HTTP ${head.status}.`, 'REGISTRY_HTTP'); }
    await uploadBlob(repository, digest, bytes);
    await verifyRemoteBlob(repository, digest, bytes.byteLength);
  }

  async function getManifest(repository, reference, expectedDigest) {
    const response = await request(manifestUrl(repository, reference), 'GET', {
      headers: {Accept: `${OCI_MANIFEST_MEDIA_TYPE}, application/vnd.oci.image.index.v1+json`},
    });
    if (response.status !== 200) { cancelBody(response); fail(`Registry manifest GET returned HTTP ${response.status}.`, 'REGISTRY_HTTP'); }
    const mediaType = response.headers.get('content-type')?.split(';')[0].trim();
    if (mediaType !== OCI_MANIFEST_MEDIA_TYPE) fail(`Registry returned unsupported manifest media type '${mediaType ?? 'missing'}'.`, 'INVALID_OCI_LAYOUT');
    const bytes = await readResponseBytes(response, MANIFEST_LIMIT, undefined, 'OCI manifest');
    const digest = `sha256:${sha256(bytes)}`;
    if (expectedDigest && digest !== expectedDigest) fail('Registry manifest bytes do not match the requested digest.', 'REGISTRY_DIGEST_MISMATCH');
    const headerDigest = response.headers.get('docker-content-digest');
    if (headerDigest && headerDigest !== digest) fail('Registry manifest digest header does not match its bytes.', 'REGISTRY_DIGEST_MISMATCH');
    let artifact;
    try { artifact = JSON.parse(bytes.toString('utf8')); }
    catch { fail('Registry manifest is invalid JSON.', 'INVALID_OCI_LAYOUT'); }
    if (artifact.schemaVersion !== 2 || artifact.mediaType !== OCI_MANIFEST_MEDIA_TYPE || artifact.artifactType !== EXTENSION_ARTIFACT_TYPE) {
      fail('Registry manifest is not a supported extension artifact.', 'INCOMPATIBLE_RUNTIME');
    }
    return {digest, bytes, artifact};
  }

  async function pullArtifact(repository, reference) {
    const resolved = validateReference(reference);
    await requireV2(repository);
    const downloaded = await getManifest(repository, resolved.value, resolved.kind === 'digest' ? resolved.value : undefined);
    const artifact = downloaded.artifact;
    if (!artifact.config || artifact.config.mediaType !== OCI_CONFIG_MEDIA_TYPE || !Array.isArray(artifact.layers) || artifact.layers.length > MAX_EXTENSION_ASSETS) {
      fail('Registry extension manifest descriptors are invalid.', 'INVALID_OCI_LAYOUT');
    }
    if (!DIGEST_RE.test(artifact.config.digest) || !Number.isSafeInteger(artifact.config.size) || artifact.config.size < 0 || artifact.config.size > CONFIG_LIMIT) {
      fail('Registry extension config descriptor is invalid.', 'INVALID_OCI_LAYOUT');
    }
    const configResponse = await request(blobUrl(repository, artifact.config.digest), 'GET');
    if (configResponse.status !== 200) { cancelBody(configResponse); fail(`Registry config blob GET returned HTTP ${configResponse.status}.`, 'REGISTRY_HTTP'); }
    const configBytes = await readResponseBytes(configResponse, CONFIG_LIMIT, artifact.config.size, 'Extension config');
    if (`sha256:${sha256(configBytes)}` !== artifact.config.digest) fail('Registry extension config failed digest verification.', 'REGISTRY_DIGEST_MISMATCH');
    let config;
    try { config = JSON.parse(configBytes.toString('utf8')); }
    catch { fail('Registry extension config is invalid JSON.', 'INVALID_OCI_LAYOUT'); }
    if (config.mediaType !== EXTENSION_CONFIG_MEDIA_TYPE) fail('Registry extension config media type is unsupported.', 'INVALID_OCI_LAYOUT');
    const {manifest, compatibility} = validateExtensionManifest(config.manifest, {allowIncompatibleRuntime: true});
    const expectedAssets = new Map(manifest.assets.map(asset => [asset.path, asset]));
    let totalSize = configBytes.byteLength;
    const assets = new Map();
    for (const layer of artifact.layers) {
      const assetPath = layer.annotations?.['org.opencontainers.image.title'];
      const expected = expectedAssets.get(assetPath);
      if (layer.mediaType !== OCI_LAYER_MEDIA_TYPE || !isSafeAssetPath(assetPath) || !expected || assets.has(assetPath) ||
          layer.digest !== `sha256:${expected.sha256}` || layer.size !== expected.size || !DIGEST_RE.test(layer.digest)) {
        fail(`Registry asset descriptor '${assetPath}' is invalid or does not match its manifest.`, 'ASSET_INTEGRITY');
      }
      if (layer.size > MAX_EXTENSION_ASSET_SIZE) fail(`Registry asset '${assetPath}' exceeds its size limit.`, 'REGISTRY_SIZE_LIMIT');
      totalSize += layer.size;
      if (totalSize > MAX_EXTENSION_TOTAL_SIZE) fail('Registry extension exceeds the total asset size limit.', 'REGISTRY_SIZE_LIMIT');
      const response = await request(blobUrl(repository, layer.digest), 'GET');
      if (response.status !== 200) { cancelBody(response); fail(`Registry asset GET returned HTTP ${response.status}.`, 'REGISTRY_HTTP'); }
      const bytes = await readResponseBytes(response, MAX_EXTENSION_ASSET_SIZE, layer.size, `Extension asset '${assetPath}'`);
      if (`sha256:${sha256(bytes)}` !== layer.digest) fail(`Registry asset '${assetPath}' failed digest verification.`, 'REGISTRY_DIGEST_MISMATCH');
      assets.set(assetPath, bytes);
    }
    if (assets.size !== expectedAssets.size) fail('Registry manifest has missing inventoried assets.', 'ASSET_INTEGRITY');
    assertAssetBytes(manifest, assets, {allowIncompatibleRuntime: true});
    return {
      digest: downloaded.digest,
      manifest,
      compatibility,
      manifestBytes: downloaded.bytes,
      artifact,
      configBytes,
      assets,
    };
  }

  return Object.freeze({
    kind: 'oci-distribution-http',
    registryUrl: normalized.origin + normalized.pathPrefix,
    async pushLayout({layoutDir, digest, repository, tag, beforeManifestPut}) {
      const repo = validateRepository(repository);
      const release = await readOciExtension(layoutDir, digest);
      const targetTag = tag ?? `${release.manifest.id}-${release.manifest.version}`;
      if (!TAG_RE.test(targetTag)) fail('Registry tag is invalid.', 'INVALID_REFERENCE');
      await requireV2(repo);
      await ensureBlob(repo, release.artifact.config.digest, release.ociConfigBytes);
      for (const layer of release.artifact.layers) {
        const bytes = release.assets.get(layer.annotations['org.opencontainers.image.title']);
        await ensureBlob(repo, layer.digest, bytes);
      }
      // The publisher may recheck current authority after blob uploads and immediately before the tag effect.
      await beforeManifestPut?.();
      const response = await request(manifestUrl(repo, targetTag), 'PUT', {
        headers: {'Content-Type': OCI_MANIFEST_MEDIA_TYPE, 'Content-Length': String(release.ociManifestBytes.byteLength)},
        body: release.ociManifestBytes,
        duplex: 'half',
      });
      if (response.status !== 201) { cancelBody(response); fail(`Registry manifest PUT returned HTTP ${response.status}.`, 'REGISTRY_HTTP'); }
      if (response.headers.get('docker-content-digest') !== digest) fail('Registry manifest PUT returned the wrong digest.', 'REGISTRY_DIGEST_MISMATCH');
      await readResponseBytes(response, 64 * 1024, undefined, 'Registry manifest PUT response');
      const verified = await getManifest(repo, digest, digest);
      if (!verified.bytes.equals(release.ociManifestBytes)) fail('Registry manifest differs from the published OCI layout.', 'REGISTRY_DIGEST_MISMATCH');
      return {digest, repository: repo, tag: targetTag, registryUrl: normalized.origin + normalized.pathPrefix};
    },
    async pullToLayout({repository, reference, layoutDir, layoutReference}) {
      const repo = validateRepository(repository);
      const release = await pullArtifact(repo, reference);
      const refName = layoutReference ?? `${release.manifest.id}-${release.manifest.version}`;
      if (!TAG_RE.test(refName)) fail('OCI layout reference is invalid.', 'INVALID_REFERENCE');
      const target = path.resolve(layoutDir);
      const stage = `${target}.pull-stage-${process.pid}-${randomBytes(6).toString('hex')}`;
      await mkdir(path.dirname(target), {recursive: true});
      await mkdir(stage, {recursive: true});
      try {
        await writeNewLayout(stage, release.digest, release.manifestBytes, release.artifact, release.configBytes, release.assets, refName);
        const verified = await readOciExtension(stage, release.digest);
        if (!verified.ociManifestBytes.equals(release.manifestBytes)) fail('Staged OCI manifest failed final verification.', 'REGISTRY_DIGEST_MISMATCH');
        await addVerifiedLayout({
          stageDir: stage,
          targetDir: target,
          digest: release.digest,
          layoutReference: refName,
          manifestBytes: release.manifestBytes,
          configBytes: release.configBytes,
          assets: release.assets,
        });
      } finally {
        await rm(stage, {recursive: true, force: true});
      }
      return {digest: release.digest, repository: repo, reference, layoutReference: refName, layoutDir: target, manifest: release.manifest, availability: release.compatibility.available ? 'available' : 'unavailable', reason: release.compatibility.reason};
    },
  });
}

export {createReleaseRegistryTransport as createOciDistributionTransport};
