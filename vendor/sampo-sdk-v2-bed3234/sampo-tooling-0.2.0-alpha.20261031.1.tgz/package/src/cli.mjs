#!/usr/bin/env node
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {
  activateOciExtension, createOciDistributionTransport, packExtensionToOciLayout,
  readLocalCatalog, readOciExtension, inspectAuthoringDirectory, inspectAuthoringRelease,
} from './index.mjs';

const toolingDir = path.dirname(fileURLToPath(import.meta.url));
const sampoDir = path.resolve(toolingDir, '../../..');
const defaultRuntimeDir = path.join(sampoDir, '.runtime');

function usage() {
  console.log(`Sampo extension tooling\n\nCommands:\n  sampo-extension doctor <package-dir>\n  sampo-extension inspect <oci-layout-dir> <sha256:digest>\n  sampo-extension pack <package-dir> <oci-layout-dir>\n  sampo-extension push <oci-layout-dir> <sha256:digest> <registry-url> <repository> [tag] [--plain-http]\n  sampo-extension pull <registry-url> <repository> <tag-or-digest> <oci-layout-dir> [--plain-http]\n  sampo-extension activate <oci-layout-dir> <sha256:digest> [--runtime <dir>]\n  sampo-extension catalog [--runtime <dir>]\n\nLoopback HTTP requires --plain-http. Registry auth may be supplied by the operator as SAMPO_OCI_AUTHORIZATION; it is never printed or sent to a browser.`);
}

function runtimeArg(args) {
  const index = args.indexOf('--runtime');
  if (index < 0) return defaultRuntimeDir;
  if (!args[index + 1] || args[index + 1].startsWith('--')) throw new Error('--runtime requires a directory.');
  return path.resolve(args[index + 1]);
}

function registryTransport(registryUrl, allowLoopbackHttp) {
  return createOciDistributionTransport({
    registryUrl,
    authorization: process.env.SAMPO_OCI_AUTHORIZATION,
    allowLoopbackHttp,
  });
}

const [command, ...args] = process.argv.slice(2);
const allowLoopbackHttp = args.includes('--plain-http');
const values = args.filter(arg => arg !== '--plain-http');

try {
  if (command === 'doctor' || command === 'inspect') {
    if (args.length !== (command === 'doctor' ? 1 : 2) || args.some(value => value.startsWith('--'))) {usage(); process.exitCode = 2;}
    else {
      const report = command === 'doctor' ? await inspectAuthoringDirectory(path.resolve(args[0])) : await inspectAuthoringRelease(path.resolve(args[0]), args[1]);
      console.log(JSON.stringify(report, null, 2));
      if (report.status === 'attention-required') process.exitCode = 1;
    }
  } else if (command === 'pack') {
    if (values.length !== 2) { usage(); process.exitCode = 2; }
    else {
      const result = await packExtensionToOciLayout({sourceDir: path.resolve(values[0]), layoutDir: path.resolve(values[1])});
      console.log(JSON.stringify({status: 'packed', reference: result.reference, digest: result.digest, layoutDir: result.layoutDir}, null, 2));
    }
  } else if (command === 'push') {
    if (values.length < 4 || values.length > 5) { usage(); process.exitCode = 2; }
    else {
      const [layoutDir, digest, registryUrl, repository, requestedTag] = values;
      const absoluteLayout = path.resolve(layoutDir);
      const release = await readOciExtension(absoluteLayout, digest);
      const tag = requestedTag ?? `${release.manifest.id}-${release.manifest.version}`;
      const result = await registryTransport(registryUrl, allowLoopbackHttp).pushLayout({layoutDir: absoluteLayout, digest, repository, tag});
      console.log(JSON.stringify({status: 'pushed', ...result}, null, 2));
    }
  } else if (command === 'pull') {
    if (values.length !== 4) { usage(); process.exitCode = 2; }
    else {
      const [registryUrl, repository, reference, layoutDir] = values;
      const result = await registryTransport(registryUrl, allowLoopbackHttp).pullToLayout({repository, reference, layoutDir: path.resolve(layoutDir)});
      console.log(JSON.stringify({status: result.availability === 'unavailable' ? 'unavailable' : 'pulled', ...result}, null, 2));
    }
  } else if (command === 'activate') {
    if (values.length < 2) { usage(); process.exitCode = 2; }
    else {
      const result = await activateOciExtension({layoutDir: path.resolve(values[0]), digest: values[1], runtimeDir: runtimeArg(args)});
      console.log(JSON.stringify(result.availability === 'unavailable'
        ? {status: 'unavailable', digest: result.digest, reason: result.catalogEntry.reason}
        : {status: 'installed', digest: result.digest, catalogEntry: result.catalogEntry}, null, 2));
    }
  } else if (command === 'catalog') {
    console.log(JSON.stringify(await readLocalCatalog(runtimeArg(args)), null, 2));
  } else {
    usage();
    process.exitCode = command ? 2 : 0;
  }
} catch (error) {
  console.error(JSON.stringify({error: {code: error.code ?? 'ERROR', message: error.message}}, null, 2));
  process.exitCode = 1;
}
