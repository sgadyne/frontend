import assert from 'node:assert/strict';
import {createHash} from 'node:crypto';
import {lstat, readFile, stat} from 'node:fs/promises';
import {spawnSync} from 'node:child_process';
import os from 'node:os';
import path from 'node:path';

const DISTRIBUTION_COMMIT = '3220848f15d9279c66a41aa0a257469e6aede1e9';
const sha256 = bytes => createHash('sha256').update(bytes).digest('hex');
const isRecord = value => value !== null && typeof value === 'object' && !Array.isArray(value);

function normalizedAbsolute(value, label) {
  assert.equal(typeof value, 'string', `${label} must be a string`);
  assert.ok(path.isAbsolute(value), `${label} must be absolute`);
  assert.equal(path.resolve(value), value, `${label} must be normalized`);
  return value;
}

/** Pure shape and pin validation shared by the release consumer and host gate. */
export function validateNativeDistributionReceipt(receipt, {registryUrl}) {
  assert.ok(isRecord(receipt), 'Distribution receipt must be a JSON object');
  assert.equal(receipt.status, 'native-distribution-binary-and-lifecycle-pass');
  assert.ok(isRecord(receipt.distribution), 'Distribution receipt must include distribution identity');
  assert.ok(isRecord(receipt.registryProbe), 'Distribution receipt must include registry probe identity');
  const endpoint = new URL(registryUrl);
  assert.equal(endpoint.protocol, 'http:', 'native Distribution proof uses loopback HTTP only');
  assert.equal(endpoint.pathname, '/', 'native Distribution endpoint must be an origin URL');
  assert.equal(endpoint.search, '');
  assert.equal(endpoint.hash, '');
  assert.equal(endpoint.username, '');
  assert.equal(endpoint.password, '');
  const hostname = endpoint.hostname.replace(/^\[|\]$/g, '');
  assert.ok(['127.0.0.1', 'localhost', '::1'].includes(hostname), 'registry endpoint must remain loopback');
  const distribution = receipt.distribution;
  const probe = receipt.registryProbe;
  assert.equal(distribution.project, 'distribution/distribution', 'foreign registry implementation is not accepted');
  assert.equal(distribution.tag, 'v3.1.2', 'foreign Distribution version is not accepted');
  assert.equal(distribution.commit, DISTRIBUTION_COMMIT, 'foreign Distribution source commit is not accepted');
  assert.equal(distribution.privilegedInstall, false, 'Distribution proof must not use privileged installation');
  for (const field of ['archiveSha256', 'sidecarSha256', 'provenanceSha256', 'licenseSha256', 'binarySha256']) {
    assert.match(distribution[field], /^[a-f0-9]{64}$/, `Distribution receipt must include ${field}`);
  }
  normalizedAbsolute(distribution.binaryPath, 'Distribution binary path');
  assert.match(`${distribution.binaryVersionOutput ?? ''}\n${probe.binaryVersionOutput ?? ''}`, /3\.1\.2/, 'Distribution version output must name v3.1.2');
  assert.equal(probe.implementation, 'native Distribution');
  assert.equal(probe.url, registryUrl, 'registry probe endpoint must match the accepted endpoint');
  assert.ok(probe.startStopRestarted === true && probe.stopped === false && probe.liveForAcceptance === true,
    'receipt must describe the verified restarted registry as live during acceptance');
  assert.ok(isRecord(probe.lifecycle) && probe.lifecycle.initialStopCompleted === true
    && probe.lifecycle.idempotentStartKeptIdentity === true && probe.lifecycle.idempotentStopCompleted === true
    && probe.lifecycle.restartedAfterStop === true, 'receipt must prove separate idempotent start/stop and a real restart');
  assert.ok(Number.isSafeInteger(probe.firstPid) && probe.firstPid > 0 && Number.isSafeInteger(probe.pid) && probe.pid > 0,
    'receipt must include first-start and restarted PID identities');
  assert.equal(typeof probe.firstBirthIdentity, 'string');
  assert.ok(probe.firstBirthIdentity.length > 0 && probe.firstBirthIdentity.length <= 256);
  assert.equal(typeof probe.birthIdentity, 'string');
  assert.ok(probe.birthIdentity.length > 0 && probe.birthIdentity.length <= 256);
  assert.ok(probe.firstPid !== probe.pid || probe.firstBirthIdentity !== probe.birthIdentity,
    'a real restart must have a different PID or process birth identity');
  assert.equal(Number(probe.port), Number(endpoint.port), 'registry probe port must match endpoint port');
  normalizedAbsolute(probe.storageDirectory, 'Distribution registry storage path');
  normalizedAbsolute(probe.runtimeDirectory, 'Distribution runtime path');
  normalizedAbsolute(probe.renderedProfile, 'Rendered native profile path');
  assert.equal(typeof probe.startCommand, 'string');
  assert.equal(typeof probe.stopCommand, 'string');
  assert.ok(probe.startCommand.includes(distribution.binaryPath) && probe.startCommand.includes(probe.runtimeDirectory), 'start command must name the pinned binary and runtime paths');
  assert.ok(probe.stopCommand.includes(distribution.binaryPath) && probe.stopCommand.includes(probe.runtimeDirectory), 'stop command must name the pinned binary and runtime paths');
  assert.ok(isRecord(receipt.candidate), 'Distribution receipt must identify the Sampo probe candidate');
  assert.match(receipt.candidate.commit ?? '', /^[a-f0-9]{40}$/);
  assert.match(receipt.candidate.tree ?? '', /^[a-f0-9]{40}$/);
  assert.match(receipt.candidate.overlaySha256 ?? '', /^[a-f0-9]{64}$/);
  assert.match(receipt.candidate.bundleSha256 ?? '', /^[a-f0-9]{64}$/);
  return {distribution, probe, endpoint, hostname};
}

/** Parse the native start script's line-oriented owner receipt, rejecting ambiguity. */
export function parseNativeDistributionOwnerReceipt(text) {
  assert.equal(typeof text, 'string', 'native owner receipt must be text');
  const values = new Map();
  for (const line of text.split(/\r?\n/)) {
    if (!line) continue;
    const split = line.indexOf('=');
    assert.ok(split > 0, 'native owner receipt contains a malformed line');
    const key = line.slice(0, split), value = line.slice(split + 1);
    assert.ok(!values.has(key), `native owner receipt contains duplicate ${key}`);
    values.set(key, value);
  }
  for (const key of ['pid', 'birth', 'command', 'token', 'config', 'binary']) {
    assert.ok(values.get(key), `native owner receipt omits ${key}`);
  }
  assert.match(values.get('pid'), /^[1-9][0-9]*$/);
  return Object.fromEntries(values);
}

/** Verify the exact pinned native Distribution process currently serving the loopback registry. */
export async function verifyNativeDistributionProcess({
  distributionReceiptPath,
  registryUrl,
  registryBinary,
  repository = 'sampo/finance',
  runtimeDirectory: requestedRuntimeDirectory,
  storageDirectory: requestedStorageDirectory,
  pidFile: requestedPidFile,
  ownerFile: requestedOwnerFile,
  io = {},
}) {
  const read = io.readFile ?? readFile;
  const statPath = io.lstat ?? lstat;
  const followStatPath = io.stat ?? stat;
  const spawn = io.spawnSync ?? spawnSync;
  const fetchEndpoint = io.fetch ?? globalThis.fetch;
  const platform = io.platform ?? process.platform;
  const architecture = io.architecture ?? os.arch();
  assert.equal(platform, 'linux', 'native Distribution acceptance requires Linux');
  assert.equal(architecture, 'x64', 'native Distribution acceptance requires linux/amd64');
  normalizedAbsolute(distributionReceiptPath, 'Distribution receipt path');
  const receiptBytes = await read(distributionReceiptPath);
  const receiptText = Buffer.isBuffer(receiptBytes) ? receiptBytes.toString('utf8') : String(receiptBytes);
  const receipt = JSON.parse(receiptText);
  const {distribution, probe, endpoint, hostname} = validateNativeDistributionReceipt(receipt, {registryUrl});
  const binary = normalizedAbsolute(distribution.binaryPath, 'Distribution binary path');
  assert.equal(path.resolve(registryBinary ?? ''), binary, 'registryBinary must be the exact binary path in the pinned receipt');
  const binaryInfo = await statPath(binary);
  assert.ok(binaryInfo.isFile() && !binaryInfo.isSymbolicLink(), 'verified Distribution binary must be a regular owned file');
  const binaryBytes = await read(binary);
  const binaryHash = sha256(binaryBytes);
  assert.equal(binaryHash, distribution.binarySha256, 'verified Distribution binary bytes changed');
  const versionResult = spawn(binary, ['--version'], {encoding: 'utf8'});
  assert.equal(versionResult.status, 0, 'verified Distribution binary must return its version');
  const binaryVersionOutput = `${versionResult.stdout ?? ''}\n${versionResult.stderr ?? ''}`.trim();
  assert.match(binaryVersionOutput, /3\.1\.2/, 'running native binary must still report v3.1.2');

  const runtimeDirectory = normalizedAbsolute(requestedRuntimeDirectory ?? probe.runtimeDirectory, 'Distribution runtime path');
  const storageDirectory = normalizedAbsolute(requestedStorageDirectory ?? probe.storageDirectory, 'Distribution storage path');
  assert.equal(runtimeDirectory, probe.runtimeDirectory, 'registry runtime path differs from the pinned probe');
  assert.equal(storageDirectory, probe.storageDirectory, 'registry storage path differs from the pinned probe');
  const storageInfo = await statPath(storageDirectory);
  assert.ok(storageInfo.isDirectory() && !storageInfo.isSymbolicLink(), 'registry storage must be an owned real directory');
  const pidFile = normalizedAbsolute(requestedPidFile ?? path.join(runtimeDirectory, 'service/registry.pid'), 'registry PID file');
  const ownerFile = normalizedAbsolute(requestedOwnerFile ?? `${pidFile}.owner`, 'registry owner file');
  const pidInfo = await statPath(pidFile);
  assert.ok(pidInfo.isFile() && !pidInfo.isSymbolicLink(), 'live registry PID receipt must be a regular file');
  const ownerInfo = await statPath(ownerFile);
  assert.ok(ownerInfo.isFile() && !ownerInfo.isSymbolicLink(), 'live registry owner receipt must be a regular file');
  const owner = parseNativeDistributionOwnerReceipt(await read(ownerFile, 'utf8'));
  const pidText = (await read(pidFile, 'utf8')).trim();
  assert.match(pidText, /^[1-9][0-9]*$/);
  const pid = Number(pidText);
  assert.ok(Number.isSafeInteger(pid));
  assert.equal(owner.pid, pidText, 'registry PID and owner receipts must agree');
  assert.equal(probe.pid, pid, 'live PID must match the restarted process recorded in the lifecycle receipt');
  assert.equal(owner.birth, probe.birthIdentity, 'live birth identity must match the restarted process receipt');
  assert.equal(owner.binary, binary, 'live registry must use the exact verified binary');
  const command = owner.command;
  const configFile = normalizedAbsolute(owner.config, 'registry config path');
  assert.equal(command, `${binary} serve ${configFile}`, 'live registry command must match the exact binary/config paths');
  const serviceDirectory = path.join(runtimeDirectory, 'service');
  assert.ok(configFile.startsWith(`${serviceDirectory}${path.sep}`) && path.basename(configFile).startsWith('registry-') && configFile.endsWith('.yml'), 'registry config must be under its owned service directory');
  const configInfo = await statPath(configFile);
  assert.ok(configInfo.isFile() && !configInfo.isSymbolicLink(), 'registry config must be a regular owned file');
  const registryConfig = await read(configFile, 'utf8');
  assert.ok(registryConfig.includes(`rootdirectory: ${JSON.stringify(storageDirectory)}`), 'registry config must write to the pinned storage path');
  const address = hostname.includes(':') ? `[${hostname}]:${endpoint.port}` : `${hostname}:${endpoint.port}`;
  assert.ok(registryConfig.includes(`addr: ${JSON.stringify(address)}`), 'registry config must bind the exact loopback endpoint');
  const processCommand = spawn('ps', ['-p', pidText, '-o', 'args='], {encoding: 'utf8'});
  assert.equal(processCommand.status, 0, 'live registry process must be observable by exact PID');
  assert.equal(processCommand.stdout.trim(), command, 'live process command must match the native owner receipt');
  const procStatBytes = await read(`/proc/${pid}/stat`, 'utf8');
  const procStat = Buffer.isBuffer(procStatBytes) ? procStatBytes.toString('utf8') : String(procStatBytes);
  const procFields = procStat.slice(procStat.lastIndexOf(')') + 2).trim().split(/\s+/);
  assert.ok(procFields[0] && !['Z', 'X'].includes(procFields[0][0]), 'registry process must be live, not a zombie');
  const bootBytes = await read('/proc/sys/kernel/random/boot_id', 'utf8');
  const bootId = (Buffer.isBuffer(bootBytes) ? bootBytes.toString('utf8') : String(bootBytes)).trim();
  const birth = `${bootId}:${procFields[19]}`;
  assert.equal(owner.birth, birth, 'process birth identity must match the native owner receipt');
  const [mappedBinary, onDiskBinary] = await Promise.all([followStatPath(`/proc/${pid}/exe`), followStatPath(binary)]);
  assert.equal(mappedBinary.dev, onDiskBinary.dev, 'running executable device must match the verified binary');
  assert.equal(mappedBinary.ino, onDiskBinary.ino, 'running executable inode must match the verified binary');
  assert.equal(Number(probe.port), Number(endpoint.port));
  const health = await fetchEndpoint(`${registryUrl}/v2/`, {
    method: 'GET', redirect: 'manual', cache: 'no-store', signal: AbortSignal.timeout(3000),
  });
  assert.equal(health.status, 200, 'pinned native Distribution endpoint must be live at /v2/');
  return {
    implementation: 'distribution/distribution', version: '3.1.2', binaryVersionOutput,
    endpoint: registryUrl, repository, port: Number(endpoint.port),
    distributionReceiptPath, distributionReceiptSha256: sha256(receiptBytes),
    upstreamCommit: distribution.commit,
    verifiedByCandidate: receipt.candidate.commit, verifiedByTree: receipt.candidate.tree,
    verifiedByOverlaySha256: receipt.candidate.overlaySha256, verifiedByBundleSha256: receipt.candidate.bundleSha256,
    startCommand: probe.startCommand, stopCommand: probe.stopCommand,
    binaryPath: binary, binarySha256: binaryHash,
    archiveSha256: distribution.archiveSha256, sidecarSha256: distribution.sidecarSha256,
    provenanceSha256: distribution.provenanceSha256, licenseSha256: distribution.licenseSha256,
    storageDirectory, runtimeDirectory, pid, birthIdentity: birth, commandReceipt: command,
    pidFile, ownerFile, configFile, liveAtAcceptance: true,
  };
}
