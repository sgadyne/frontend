# Distribution: packages, releases and templates

| Object | Identity | Effect |
| --- | --- | --- |
| Package | Manifest, asset inventory and runtime peers | Declares app/widget/template contributions and optional backend requirements |
| Release | OCI manifest SHA-256 | Immutable exact bytes; registry tags are discovery labels |
| Admission/decision | Exact release and admission digest, current revision | Operator reviews, approves or revokes a release |
| Installation | Approved release plus verified cached assets | Makes contributions available to entitled users |
| Workspace pin | Exact installed contribution/release | Saved composition uses this version until explicit upgrade/rollback |
| Template | Reviewed composition, views and optional definitions/remap paths | Creates independent local objects; transfers no authority or backend installation |

An author builds and packs an exact release. The receiving operator stages its
digest, reviews admission, approves and installs it. A workspace then pins an
installed contribution explicitly. Publishing a registry tag does not perform
any of the receiving installation's approval or workspace-upgrade steps.

Managed stage, decision and install are separate administrator mutations with current revision, admission digest where required and retained idempotency key. `POST /api/community/stage`, `/api/community/releases/:digest/decision` and `/api/community/releases/:digest/install` never change a workspace pin implicitly. Catalogs are projections, not approval authority. Revocation blocks later access; it cannot unexecute code already loaded in a browser.

## Package and transport commands

This package builds and verifies independently released trusted React ESM
extensions using Node built-ins.

```sh
node packages/tooling/src/cli.mjs pack <extension-package-dir> <oci-layout-dir>
node packages/tooling/src/cli.mjs push <oci-layout-dir> <sha256:digest> <registry-url> <repository> [tag] --plain-http
node packages/tooling/src/cli.mjs pull <registry-url> <repository> <tag-or-digest> <oci-layout-dir> --plain-http
node packages/tooling/src/cli.mjs activate <oci-layout-dir> sha256:<oci-manifest-hex>
node packages/tooling/src/cli.mjs catalog
```

`--plain-http` is required for loopback HTTP registries; remote registry URLs
must use HTTPS. Optional operator credentials can be supplied as
`SAMPO_OCI_AUTHORIZATION` (a single `Bearer ...` or `Basic ...` header value).
Credentials stay in the publisher process and are never written to a catalog,
release, runtime config or browser response.

An extension package has `manifest.json` at its root and an asset inventory
covering the entry module, styles, imported chunks and any other served files.
Every inventoried file is checked for safe relative paths, regular-file status,
size and SHA-256. Runtime ABI, SDK and React versions are checked before the
release can enter the immutable cache. The extension entry is never imported by
the publisher, installer or server.

The package digest is the digest of its OCI manifest. The layout stores a
project-specific OCI artifact whose config holds the extension manifest and
whose layers are raw inventoried assets. Activation verifies the OCI manifest,
config, every blob, every asset and the manifest contract before atomically
activating a cache directory or updating `catalog.json`. An unsupported runtime
adapter may appear in the local catalog as unavailable with a reason; it is not
cached or served.

The artifact gateway serves only cached assets at immutable
`/extensions/sha256-<hex>/<path>` URLs. It rechecks the requested file digest at
serve time and rejects tampered bytes and traversal paths. Browser code never
receives OCI registry credentials.

`activate` is for the unmanaged local demo cache. It refuses a runtime with a
`community-managed.json` marker or `community/authority.json`; managed
installations must use the guarded community stage, approval and install API.
An OCI digest proves byte identity, not code isolation. Installed React
extensions share the host's authority.

## OCI registry transport

The native OCI layout and built-in OCI Distribution HTTP transport are separate
adapters. HTTP transfer uses blob HEAD/GET/POST/PUT and manifest GET/PUT, checks
all returned digests and sizes, and does not follow redirects. Upload Locations
must stay within the configured registry origin and repository path. Pulls can
resolve tags, but the returned OCI manifest digest is verified and should be
used for activation. The local catalog changes only on explicit activation;
registry tags and catalog entries are separate.

An optional `createOrasRegistryTransport()` adapter is also available and relies
on ORAS' own credential store. ORAS is not required by the built-in transport.
The adapter follows the documented ORAS `cp --from-oci-layout` and
`cp --to-oci-layout` forms ([ORAS `cp` command](https://oras.land/docs/commands/oras_cp/)).
## Whole-workspace templates

Owners and editors can export a saved workspace for review. The export includes the root composition, all named views and the active view, with exact extension release digests. The top-level workspace identity, revision, membership and preferences are not included. Panel view state and application session state are excluded by default; choosing to include them is explicit. Configurations, layout data and arbitrary strings can contain sensitive information. The reserved-field check is not a secret scanner: review the exact JSON before downloading or publishing it.

Save the current workspace first. The server exports the requested saved revision and refuses a stale revision or dependencies that are unavailable, revoked, unapproved or not entitled. Provider bindings, datasets, files and network resources do not travel with a template. A consumer needs the exact installed, approved releases and grants. Creating a workspace preserves panel, connection and view IDs within the new workspace, assigns fresh workspace and session IDs, and grants ownership to the creator. Existing composition templates retain their apply-to-current-workspace behavior.

Remote publication is disabled unless a managed community deployment explicitly configures it. For example, add a `publishing` object to an existing `community` configuration:

```json
{
  "enabled": true,
  "sources": [{
    "id": "curated",
    "registryUrl": "https://registry.example.invalid",
    "repository": "organization/extensions",
    "namespacePrefix": "organization.",
    "publisher": "Organization",
    "authorizationEnv": "SAMPO_REGISTRY_READ_AUTH"
  }],
  "publishing": {
    "sourceId": "curated",
    "authorizationEnv": "SAMPO_REGISTRY_PUBLISH_AUTH"
  }
}
```

Set the separate server-side publisher variable to the static `Bearer ...` or `Basic ...` authorization header accepted by the existing OCI transport. Do not put the credential in the config file or browser. Registry token challenges and refresh are not implemented. The fixed source supplies the registry, repository, namespace and publisher; a request cannot select a different destination. Only an authenticated administrator can preview and publish remotely. A preview requires an extension ID, version, license identifier and nonempty LICENSE and NOTICE text. The generated extension contains inert host-owned entry code and the reviewed JSON. The final button publishes the frozen artifact under a digest-derived tag; it does not stage, approve or install the release. Those remain separate administrator decisions.

Publication previews and operation records are retained under the runtime writer authority, with a limit of 100 previews. Back up the frozen layouts with the runtime. If PostgreSQL is the metadata authority, back up its metadata records as well. Protect them as workspace data. The operation ID and reviewed digests identify the effect. An interrupted push or lost response is reported as **unknown**: a retry of that operation returns the same outcome without another push. An administrator can explicitly verify the fixed registry. The server reports success only if the reviewed tag resolves to the exact verified artifact; missing or unavailable registry evidence remains unknown. No automatic claim of absence or success is made. Tab storage keeps the operation ID and a submitted workspace candidate for browser reconciliation after a reload. If that storage is unavailable, the browser refuses to submit a new publication or workspace creation that it cannot safely reconcile.


### Portable workflow templates

The optional portable workflow section selects exact current workflow definitions and declares existing widget config/view-state or session-state reference paths to remap. Its template schema is 2; ordinary schema 1 templates remain compatible. Strict generated packages use manifest schema 2 with inventoried inert workflow JSON assets and exact logical requirement/operation declarations. The reserved checks reject known private runtime shapes, but arbitrary JSON still requires review.

In the recipient environment, an operator installs the exact frontend dependencies and template. The catalog import dialog requires explicit local scope and authorized existing binding choices, then stages fresh workspace/session/workflow IDs. It rechecks requirements before creation/publication. Unknown create/publish responses retain the same IDs through reload and reconcile through exact reads. Execution is a separate action; no source grants, private provider mapping, run receipt or output is transferred. Only declared references change; external links retain their addresses and separate authority.

Recovery details are private tab storage, not cross-browser durable storage. Save the provided recovery-details file before closing a tab with an uncertain import; inspect/reconcile its exact IDs without starting a replacement. The UI imports installed catalog templates; downloaded arbitrary JSON is not a separate entry point.

## Authority and recovery

An initialized managed runtime fails closed if approval authority is missing or corrupt. Keep its authority marker, metadata, layouts and installed bytes together; never remove the marker to use unmanaged activation. Byte-only installation recovery revalidates exact artifacts and current policy. Interrupted external publication remains unknown until exact registry evidence resolves it; never automatically push again.

Back up the stopped runtime and selected metadata authority together with retained registry artifacts. [Deployment](../../deploy/README.md) owns migration and recovery procedures. Trusted React extensions share host authority; inventory hashes establish byte identity, not an untrusted-code sandbox.
