/** Renderer-facing roles only. Toolkit packages retain their native theme adapters. */
export const semanticTokenKeys = Object.freeze([
  'color.primary', 'color.background', 'color.surface', 'color.text',
  'color.text.muted', 'color.border', 'color.focus', 'typography.family',
  'typography.size', 'shape.control.radius', 'control.height', 'control.density',
  'color.surface.raised', 'color.surface.sunken', 'color.primary.soft',
  'color.border.strong', 'color.success', 'color.warning', 'color.danger',
  'typography.size.meta', 'typography.size.section', 'typography.size.page',
  'shape.surface.radius', 'shape.overlay.radius',
  'spacing.1', 'spacing.2', 'spacing.3', 'spacing.4', 'spacing.6', 'spacing.8',
  'motion.feedback', 'motion.transition',
]);

const palettes = Object.freeze({
  light: Object.freeze({
    'color.primary': '#285d75', 'color.background': '#f4f6f8',
    'color.surface': '#ffffff', 'color.text': '#182932',
    'color.text.muted': '#52636d', 'color.border': '#c2cdd3', 'color.focus': '#146f96',
    'color.surface.raised': '#ffffff', 'color.surface.sunken': '#edf2f5',
    'color.primary.soft': '#e7f1f5', 'color.border.strong': '#73838f',
    'color.success': '#246543', 'color.warning': '#79531d', 'color.danger': '#a23a36',
  }),
  dark: Object.freeze({
    'color.primary': '#7cc4e8', 'color.background': '#0f1720',
    'color.surface': '#172330', 'color.text': '#edf3f8',
    'color.text.muted': '#a7b6c2', 'color.border': '#617382', 'color.focus': '#82ccff',
    'color.surface.raised': '#1e2d3b', 'color.surface.sunken': '#111b25',
    'color.primary.soft': '#173849', 'color.border.strong': '#758a9c',
    'color.success': '#8dd5ad', 'color.warning': '#edc887', 'color.danger': '#ffb0aa',
  }),
});

/**
 * Resolve one complete immutable role map. Unknown brand keys are left to their
 * owner; legacy host CSS variables can remain alongside this map in BrandProfile.
 */
export function createSemanticTokens(overrides = {}, {mode = 'light', density = 'comfortable'} = {}) {
  if (mode !== 'light' && mode !== 'dark') throw new TypeError('Unknown Sampo color mode');
  if (overrides === null || typeof overrides !== 'object' || Array.isArray(overrides)) {
    throw new TypeError('Semantic tokens must be a role map');
  }
  const own = key => Object.hasOwn(overrides, key) ? overrides[key] : undefined;
  density = own('control.density') ?? density;
  if (density !== 'compact' && density !== 'comfortable') throw new TypeError('Unknown Sampo control density');
  const tokens = {
    ...palettes[mode],
    'typography.family': 'Inter, "Segoe UI", Arial, sans-serif',
    'typography.size': '14px',
    'shape.control.radius': '6px',
    'control.height': density === 'compact' ? '28px' : '36px',
    'control.density': density,
    'typography.size.meta': '12px', 'typography.size.section': '18px', 'typography.size.page': '28px',
    'shape.surface.radius': '12px', 'shape.overlay.radius': '16px',
    'spacing.1': '4px', 'spacing.2': '8px', 'spacing.3': '12px',
    'spacing.4': '16px', 'spacing.6': '24px', 'spacing.8': '32px',
    'motion.feedback': '120ms', 'motion.transition': '180ms',
  };
  for (const key of semanticTokenKeys) {
    const value = own(key);
    if (value === undefined) continue;
    if (typeof value !== 'string' || !value.trim()) throw new TypeError(`Invalid semantic token ${key}`);
    tokens[key] = value;
  }
  return Object.freeze(tokens);
}
