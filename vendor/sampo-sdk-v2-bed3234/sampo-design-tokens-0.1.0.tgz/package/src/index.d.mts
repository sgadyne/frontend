export type SemanticTokenKey =
  | 'color.primary' | 'color.background' | 'color.surface' | 'color.text'
  | 'color.text.muted' | 'color.border' | 'color.focus' | 'typography.family'
  | 'typography.size' | 'shape.control.radius' | 'control.height' | 'control.density'
  | 'color.surface.raised' | 'color.surface.sunken' | 'color.primary.soft'
  | 'color.border.strong' | 'color.success' | 'color.warning' | 'color.danger'
  | 'typography.size.meta' | 'typography.size.section' | 'typography.size.page'
  | 'shape.surface.radius' | 'shape.overlay.radius'
  | 'spacing.1' | 'spacing.2' | 'spacing.3' | 'spacing.4' | 'spacing.6' | 'spacing.8'
  | 'motion.feedback' | 'motion.transition';
export type SemanticTokens = Readonly<Record<SemanticTokenKey, string> & {'control.density': 'compact' | 'comfortable'}>;
export const semanticTokenKeys: readonly SemanticTokenKey[];
export function createSemanticTokens(
  overrides?: Readonly<Record<string, string>>,
  options?: {mode?: 'light' | 'dark'; density?: 'compact' | 'comfortable'},
): SemanticTokens;
