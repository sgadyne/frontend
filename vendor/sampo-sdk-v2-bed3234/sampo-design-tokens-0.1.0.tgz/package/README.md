# Sampo semantic tokens

`@sampo/design-tokens` provides renderer-facing color, typography, shape and
density roles. It has no framework, DOM, toolkit or build dependency. Blueprint,
Material UI, Ant Design and the host convert these roles with their own adapters.

```js
import {createSemanticTokens} from '@sampo/design-tokens';
const tokens = createSemanticTokens(brand.tokens, {mode: 'dark', density: 'compact'});
```

The complete role map is immutable. Explicit supported role values override the
palette. `control.density` also chooses the default `control.height`; an explicit
height wins. Unknown brand keys are ignored by this helper, so the host can
continue to consume its existing `--sampo-*` overrides independently. Invalid
known values and unsupported mode/density names fail explicitly.

Color modes express presentation preferences, not shared session state. This
package installs no CSS, resets, portals or global theme provider. Native vendor
configuration remains in the versioned renderer namespace. The caller owns
persistence of personal preferences and shared defaults.

The additive host-foundation roles include raised/sunken surfaces, primary soft
surface, a meaningful strong boundary, success/warning/danger foregrounds,
metadata/section/page sizes, surface/overlay corners, 4px-grid spacing and motion
durations. Existing roles and their values remain compatible. `color.border` is
a quiet decorative separator; use `color.border.strong` for control boundaries
that must remain identifiable. Status colors are foregrounds on opaque surfaces,
always accompanied by text or an icon. Consumers honor reduced-motion themselves.
