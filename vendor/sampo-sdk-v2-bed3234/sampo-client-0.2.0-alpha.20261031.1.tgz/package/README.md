# @sampo/client

Experimental framework-neutral client. `createSampoClient` accepts an explicit transport; `createFetchTransport` is a browser cookie-session implementation. The host owns login, session lifecycle, current CSRF token and authorization. It does not create a session or grant access.

```ts
import {createFetchTransport, createSampoClient} from '@sampo/client';
const transport = createFetchTransport({csrfToken: () => currentSession.csrfToken});
const workspace = createSampoClient({transport}).forWorkspace(workspaceId);
```

The fetch transport accepts only relative same-origin `/api/` paths, uses `credentials: 'same-origin'`, sends `X-Sampo-CSRF` on POST when supplied, and rejects redirects. An optional `fetch` implementation may be injected. It passes the `AbortSignal` through and never retries. A non-2xx response throws `SampoHttpError`, containing its status but no server body; network, abort and JSON parsing failures propagate. Successful responses must contain JSON. Refresh the token in the host callback when the session changes.

`workspace.bindings.list(context)`, `operations.list(context)`, `workflows.validate/publish/get` and `runs.start/get/list/readResult` target the registered account-backed server APIs. A configured approved provider is required for execution. A selected scope, workspace ID or exact revision grants no access; the server checks current team and workspace authority independently. Retain the exact request/idempotency key before start and the returned run ID. Never automatically reexecute an unknown outcome. See the [author quickstart](../README.md) and [external team starter](../../examples/sampodk-team-starter/README.md).

The client exposes `client.scopes.list()`, `workspace.workflows.list(context, options)`, `client.library.list(context, options)`, `client.library.put/remove(context, input, options)` and `client.navigation.resolve(target, options)`. Scope discovery retains the `{scopes}` response. Workflow and library list options accept `cursor`, `limit` (1–100) and `signal`; scope discovery accepts `signal` only. For paged collections, follow `nextCursor` until absent, including an empty final page. Workflow listing returns at most one authorized exact revision per page. Library entries contain addresses rather than target titles or grants; resolve a target separately and handle `{status: 'unavailable'}` without assuming why it is unavailable. A workflow target includes the actual `workspaceId` and exact revision; a legacy reference without a revision does not resolve to latest.

Library writes use the whole-scope snapshot revision as `expectedRevision`, which can also change when workflows, runs or bindings change. Refresh explicitly on conflict. The client validates discovery DTOs and outgoing references and page options, passes abort signals through, and never retries mutations. The existing GET/POST `SampoTransport` remains sufficient: library writes use POST subroutes. Fetch transport supplies CSRF on those writes and navigation resolution. Navigation and library addresses do not grant target access, and host-bound services are conveniences for trusted widgets rather than a sandbox.

Adding a library entry intentionally shares its complete reference with people who can read the source scope: the personal owner for a personal library, or current team members for a team library. A personal owner or team owner/admin curates those entries. Reference identifiers may be meaningful, so do not add an address to a library whose readers should not see it. Reading a shared reference grants no target access and the library does not disclose target titles or data. Resolving it performs independent current target checks; missing and forbidden targets are uniformly unavailable.

For a disposable, independently installed client check against the synthetic HTTP API, use Node 24+, npm, Git, and a Python 3.11+ environment with the exact Data Engine source identity installed as described in [the adapter README](../data-engine/README.md). The installed interpreter must pass the bridge's source verification; an arbitrary package with the same version is insufficient. The run needs a free loopback port and an npm cache containing the packaged dependencies. Run from the repository root with new absolute output directories:

```sh
npm ci --ignore-scripts
node scripts/build-sdk.mjs
mkdir -p /absolute/path/client-packs
npm pack ./packages/contracts ./packages/client --ignore-scripts --pack-destination /absolute/path/client-packs
SAMPO_BASELINE_OUTPUT=/absolute/path/new-baseline node scripts/acceptance/sampodk-baseline-artifacts.mjs
```

The baseline step requires the base commit recorded by that script to be available in the local Git object database; it creates its output directory and a synthetic widget release. Supply those outputs and the verified interpreter to the check:

```sh
SAMPO_CLIENT_CONTRACTS_TGZ=/absolute/path/client-packs/sampo-contracts-0.1.0.tgz \
SAMPO_CLIENT_TGZ=/absolute/path/client-packs/sampo-client-0.1.0.tgz \
SAMPO_BASELINE_OUTPUT=/absolute/path/new-baseline \
SAMPO_DATA_ENGINE_PYTHON=/absolute/path/to/verified/python \
node --import ./scripts/test-register.mjs --test packages/client/tests/actual-api.mjs
```

The fixture installs the two tarballs in a temporary project, provisions synthetic users and an isolated loopback server, then exercises discovery, cursor continuation, denial, abort and explicit replay of an original request after a simulated lost response. It asserts exactly one real provider prepare. Its empty page with a continuation cursor is produced by caller-side scope filtering of an actual run page; the server page itself is nonempty. This does not qualify the browser widget, PostgreSQL or external identity providers.

To reproduce the synthetic author handoff including the installed-widget browser journey, start from a clean checkout with Node 24+, npm dependencies installed, the exact source-verified Data Engine interpreter described above, and a working Chromium executable including its native shared libraries. On Linux, configure `LD_LIBRARY_PATH` if Chromium's libraries are supplied in an extracted prefix; verify the executable with `--version` first. Use an absolute output path outside the checkout that does not already exist:

```sh
SAMPO_FINISH_OUTPUT=/absolute/path/new-handoff-output \
SAMPO_DATA_ENGINE_PYTHON=/absolute/path/to/verified/python \
SAMPO_TEST_CHROMIUM=/absolute/path/to/chromium \
SAMPO_EXPECTED_WIDGET_DIGEST=sha256:REPLACE_WITH_EXACT_WIDGET_DIGEST \
node scripts/acceptance/sampodk-finish-setup.mjs
```

This builds the host and public tarballs, copies the starter outside the checkout, installs the four tarballs and the author's compiler, builds and verifies its exact release against the supplied exact widget digest, and runs the independent client and real browser checks with disposable synthetic users, registry and provider state. `receipt.json` records the source commit and tree, package and executable hashes, release digest and individual command log hashes, including failures. The browser fixture begins with the widget placed in a synthetic workspace; adding it from the catalog is a separate acceptance gate. The run needs a local copy of the historical baseline Git object, network or a populated npm cache for the author's pinned build dependencies, and available loopback ports. It does not qualify PostgreSQL, external OIDC or corporate deployments.
