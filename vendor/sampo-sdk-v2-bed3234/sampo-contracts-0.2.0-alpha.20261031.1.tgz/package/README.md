# Contracts: portable values and identities

The framework-neutral package owns serializable shapes and closed validation. Validation establishes shape and bounds; it does not establish installation, existence or authority.

| Family | Describes | Key invariant |
| --- | --- | --- |
| Manifest/release | Assets, contributions, runtime peers and logical backend requirements | Exact inventoried identity |
| Workspace/composition | Views, widgets, sessions, pins and context connections | Explicit saved relationships; opaque state preserved |
| Scope/navigation | Personal/team addresses and exact typed targets | Address is not a grant |
| Workflow/run | Logical operation declaration, immutable revision and result receipt | No arbitrary code; exact original request identity |
| Data values | Publication references and lossless typed JSON | Exact revision and value fidelity; no retention implication |

`defineWorkflow()` validates, copies and deeply freezes a declaration without executing it. Obtain operation identities through the permitted catalogue. Unknown fields, executable configuration and unsupported schema versions fail validation. Manifest schema 1 remains compatible; schema 2 adds explicit backend requirements. Workspace template schema 2 adds opt-in workflow definitions and declared remap paths.

See [SDK authoring](../README.md), [API shapes](../../server/api/docs/README.md) and [source exports](src/index.ts). New contract changes need explicit version/reader compatibility; do not redefine shared semantics inside a corporate app.

The [spatial workspace contract](SPATIAL.md) documents the independent layout variant, recipe builder, commands and persistence boundary.
