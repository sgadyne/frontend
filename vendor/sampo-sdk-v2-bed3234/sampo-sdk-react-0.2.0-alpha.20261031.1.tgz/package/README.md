# React host boundary

The product [1.0.0-beta.1 checkpoint](../../BETA.md) retains the existing SDK cohort.
Application session factories may use optional `services.data`, the same logical
prepared-data service as widgets. The host aborts and remounts sessions when their
authority or execution environment changes. Honor `services.signal`, keep saved
state free of credentials/live handles, and revalidate exact references on remount.

The hosted extension ABI renders independently packaged trusted React components. The host supplies shared React/contracts/SDK runtime imports; a widget must not bundle a second React or import private host source.

| Surface | Responsibility |
| --- | --- |
| Widget lifecycle and saved state | App-specific configuration/view state and application session state |
| Context ports | Explicit schema-compatible connections through the workspace router |
| `useHost().data` / application `services.data` | Optional prepared-data provider for logical resource reads |
| `useHost().environment` | Optional allowed-scope discovery, selection and change subscription |
| `useHost().workflows` | Optional workspace-bound discovery, run requests and original-request receipts |
| `useHost().navigation` | Optional typed, currently authorized destinations |
| `useHost().spatial` | Optional transient inspection and pinned entity association in a spatial workspace |

Host services are optional for older hosts. Respond to identity/workspace/scope generation changes, abort obsolete reads, and discard late results. Keep credentials, results and live leases outside shared saved state. The host retains original mutation identity for reconciliation; unknown work is never automatically retried.

Use the [independent widget starter](../../examples/sampodk-widget-starter/README.md). The [SDK guide](../README.md) connects it to backend requirements and distribution. React host code is trusted and shares browser authority; these conveniences do not sandbox it. Other UI libraries can be packaged within this ABI, while additional renderer frameworks remain future adapters.

The current `0.2.0-alpha.20261031.1` cohort includes [typed context](CONTEXT.md), [exact results and deliberate actions](RESULTS.md), and [workspace recipes](../contracts/RECIPES.md). Use the [current SDK packaging route](../README.md#obtain-matching-artifacts) and keep matching archives with their hash manifest. The [equipment alpha guide](../../docs/sdk-alpha-authoring.md) retains an older pinned cohort for reproducing that checkpoint.

The current cohort includes the [read-only presentation declaration](PRESENTATION.md), introduced in the earlier dynamics alpha2 checkpoint. Older qualification receipts remain tied to their original package sources.

In a spatial workspace, `useHost().spatial?.inspect({type, id, label})` opens a contextual sheet for a typed entity. `selectedEntity` tracks the current inspection; `associatedEntity` identifies the entity pinned to this widget object, if any. Prefer `associatedEntity` when showing a pinned observation so a later selection cannot relabel it. `dismiss()` closes the current inspection. Context values still travel through declared ports; this service carries presentation identity, not measurements or credentials. See the [spatial contract guide](../contracts/SPATIAL.md) and [thermal-loop example](../../examples/sampodk-thermal-loop/src/index.tsx).
