# Workspace runtime

| Runtime object | Owns | Lifetime |
| --- | --- | --- |
| WorkspaceRuntime | Composition and application sessions | Mounted workspace |
| Application session | Serializable app state and cleanup | Compatible exact app/release identity |
| Context router | Explicit edges, ordered events and bounded replay | Current composition identity |
| PreparedDataQuery | Exact read, cancellation and read-hold release | Displayed query |

```mermaid
flowchart LR
    Document[Saved composition] --> Sessions[Application sessions]
    Document --> Router[Explicit context router]
    Sessions --> Widgets[Widget instances]
    Widgets --> Router
    Widgets --> Query[Exact PreparedDataQuery]
    Query --> Provider[Authorized provider interface]
```

One `WorkspaceRuntime` owns app-session creation, serialized state, cancellation,
cleanup and a session-scoped context router. Runtime and native server use the
same plain ESM structural validator from `@sampo/contracts`. Contribution
resolution and release authorization are separate caller policy.

A compatible mounted session keeps its serialized state across document
replacement, including intentional null, false, zero and empty string. Changing
its application or exact release disposes it. Link or widget-identity changes
dispose the old context router, detach its AbortSignal hooks and clear replay.
Callers subscribe to the replacement router when their composition changes.

Context travels only over explicit saved schema-compatible edges. Sequences are
positive safe integers and increase per source port within a router. Every
listener receives isolated copies of the event and connection. Late subscribers
receive the most recently dispatched value for each linked source. A source
with no edges does not create replay state for future implicit links.

Reentrant publish queues a later event until current listeners finish, preserving
per-source order. A nested publish returns zero because its deliveries occur
when the outer call drains the queue. The outer publish reports its own direct
deliveries. Each synchronous turn permits 128 events and 10,000 callbacks;
synchronous replay nesting is at most 32; one event is at most 64 KiB UTF-8.
Exceeding a limit throws and drops the remaining queued work. Listener exceptions
also stop that turn. Accepted sequence numbers are not rolled back after a
partial delivery. A later turn can proceed with a higher sequence. These bounds
are exported as `CONTEXT_LIMITS`.

`PreparedDataQuery` owns one displayed exact read through a browser-safe
`PreparedDataProvider`. It aborts superseded requests, rejects mismatched exact
revisions, releases superseded/stale/closed publication holds, and keeps accepted
prior data while exposing refresh failure separately. Abort is cooperative at
this interface; an implementation may still return a stale response. That
response is ignored and any returned hold is released. Dispose aborts pending
work and clears listeners; server-side hold expiry remains the cleanup bound if
a provider never settles. Saved publication references carry no durable retention
right.
