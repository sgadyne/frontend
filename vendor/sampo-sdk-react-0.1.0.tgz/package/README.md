# React host boundary

The hosted extension ABI renders independently packaged trusted React components. The host supplies shared React/contracts/SDK runtime imports; a widget must not bundle a second React or import private host source.

| Surface | Responsibility |
| --- | --- |
| Widget lifecycle and saved state | App-specific configuration/view state and application session state |
| Context ports | Explicit schema-compatible connections through the workspace router |
| `useHost().environment` | Optional allowed-scope discovery, selection and change subscription |
| `useHost().workflows` | Optional workspace-bound discovery, run requests and original-request receipts |
| `useHost().navigation` | Optional typed, currently authorized destinations |

Host services are optional for older hosts. Respond to identity/workspace/scope generation changes, abort obsolete reads, and discard late results. Keep credentials, results and live leases outside shared saved state. The host retains original mutation identity for reconciliation; unknown work is never automatically retried.

Use the [independent widget starter](../../examples/sampodk-widget-starter/README.md). The [SDK guide](../README.md) connects it to backend requirements and distribution. React host code is trusted and shares browser authority; these conveniences do not sandbox it. Other UI libraries can be packaged within this ABI, while additional renderer frameworks remain future adapters.
