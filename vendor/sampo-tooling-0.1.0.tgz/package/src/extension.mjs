import {validateTheme} from './theme.mjs';
import {createHash} from 'node:crypto';
import {lstat, readFile} from 'node:fs/promises';
import path from 'node:path';
import {validateDeclaredWorkflow, validatePackageBackend, validatePackageWorkflowAssets} from './package-requirements.mjs';

// Keep these values in sync with the public contracts package. They are repeated
// here so the publisher and server remain runnable directly on built-in Node.
export const RUNTIME_ABI = 1;
export const SDK_VERSION = '0.1.0';
export const REACT_VERSION = '19.2.8';
export const EXTENSION_ARTIFACT_TYPE = 'application/vnd.sampo.extension.v1';
export const EXTENSION_CONFIG_MEDIA_TYPE = 'application/vnd.sampo.extension.config.v1+json';
export const OCI_MANIFEST_MEDIA_TYPE = 'application/vnd.oci.image.manifest.v1+json';
export const OCI_CONFIG_MEDIA_TYPE = EXTENSION_CONFIG_MEDIA_TYPE;
export const OCI_LAYER_MEDIA_TYPE = 'application/vnd.sampo.extension.asset.v1';
export const MAX_EXTENSION_ASSET_SIZE = 50 * 1024 * 1024;
export const MAX_EXTENSION_TOTAL_SIZE = 250 * 1024 * 1024;
export const MAX_EXTENSION_ASSETS = 2000;

export class ExtensionValidationError extends Error {
  constructor(message, code = 'INVALID_EXTENSION') {
    super(message);
    this.name = 'ExtensionValidationError';
    this.code = code;
  }
}

export function sha256(bytes) {
  return createHash('sha256').update(bytes).digest('hex');
}

export function isSafeAssetPath(value) {
  if (typeof value !== 'string' || value.length === 0 || value.length > 240) return false;
  if (value.includes('\\') || value.includes('%') || value.includes(':') || value.startsWith('/')) return false;
  const parts = value.split('/');
  return parts.every(part => part.length > 0 && part !== '.' && part !== '..' && /^[A-Za-z0-9._~-]+$/.test(part));
}

function requireString(value, field, max = 500) {
  if (typeof value !== 'string' || value.trim().length === 0 || value.length > max) {
    throw new ExtensionValidationError(`Manifest field '${field}' must be a non-empty string.`);
  }
}

function isRecord(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

function validateJsonValue(value, field = 'value', depth = 0) {
  if (depth > 64) throw new ExtensionValidationError(`Manifest ${field} is nested too deeply.`);
  if (value === null || typeof value === 'string' || typeof value === 'boolean') return;
  if (typeof value === 'number' && Number.isFinite(value)) return;
  if (Array.isArray(value)) {
    for (const item of value) validateJsonValue(item, field, depth + 1);
    return;
  }
  if (isRecord(value)) {
    for (const [key, item] of Object.entries(value)) {
      if (key === '__proto__' || key === 'prototype' || key === 'constructor') {
        throw new ExtensionValidationError(`Manifest ${field} contains a forbidden object key.`);
      }
      validateJsonValue(item, field, depth + 1);
    }
    return;
  }
  throw new ExtensionValidationError(`Manifest ${field} must contain JSON values only.`);
}

export function validateExtensionManifest(manifest, {allowIncompatibleRuntime = false} = {}) {
  if (!isRecord(manifest)) throw new ExtensionValidationError('Extension manifest must be an object.');
  if (manifest.schemaVersion !== 1 && manifest.schemaVersion !== 2) throw new ExtensionValidationError('Unsupported extension manifest schema.', 'INCOMPATIBLE_SCHEMA');
  requireString(manifest.id, 'id', 120);
  if (!/^[A-Za-z0-9][A-Za-z0-9._-]*$/.test(manifest.id)) throw new ExtensionValidationError('Manifest id must use letters, digits, dot, underscore or hyphen.');
  requireString(manifest.version, 'version', 80);
  if (!/^[A-Za-z0-9_][A-Za-z0-9._+-]*$/.test(manifest.version)) throw new ExtensionValidationError('Manifest version must be safe for an OCI layout reference.');
  requireString(manifest.publisher, 'publisher', 200);
  requireString(manifest.license, 'license', 120);

  const themeRuntime = manifest.runtime?.kind === 'declarative-theme';
  if (themeRuntime && manifest.schemaVersion !== 1) throw new ExtensionValidationError('Declarative themes require manifest schema 1.');
  if (!isRecord(manifest.runtime) || !Number.isSafeInteger(manifest.runtime.abi)) {
    throw new ExtensionValidationError('Manifest runtime must declare an adapter kind and ABI.');
  }
  requireString(manifest.runtime.kind, 'runtime.kind', 120);
  if (!themeRuntime) requireString(manifest.runtime.sdk, 'runtime.sdk', 80);
  if (themeRuntime && (manifest.runtime.abi !== 1 || Object.keys(manifest.runtime).some(key => !['kind', 'abi'].includes(key)))) throw new ExtensionValidationError('Declarative theme runtime must use ABI 1 and contain no executable runtime fields.');
  if (manifest.runtime.react !== undefined && (typeof manifest.runtime.react !== 'string' || manifest.runtime.react.length > 80)) {
    throw new ExtensionValidationError('Manifest runtime.react must be a version string when provided.');
  }
  if (manifest.runtime.peers !== undefined) {
    if (!isRecord(manifest.runtime.peers) || Object.entries(manifest.runtime.peers).some(([name, version]) =>
      !/^(?:@[A-Za-z0-9._-]+\/)?[A-Za-z0-9._-]+$/.test(name) || typeof version !== 'string' || version.length > 120)) {
      throw new ExtensionValidationError('Manifest runtime.peers must map package names to version strings.');
    }
  }
  let compatibilityReason;
  let compatibilityCode = 'INCOMPATIBLE_RUNTIME';
  if (themeRuntime) {
    if (manifest.entry !== undefined || manifest.styles !== undefined || !Array.isArray(manifest.capabilities) || manifest.capabilities.length) throw new ExtensionValidationError('Declarative themes cannot declare entry, styles, or capabilities.');
  } else if (manifest.runtime.kind !== 'trusted-react-esm') {
    compatibilityReason = `Runtime adapter '${manifest.runtime.kind}' is not supported by this host.`;
  } else {
    requireString(manifest.runtime.react, 'runtime.react', 80);
    if (manifest.runtime.abi !== RUNTIME_ABI) {
      compatibilityCode = 'INCOMPATIBLE_ABI';
      compatibilityReason = `Runtime ABI ${String(manifest.runtime.abi)} is incompatible with ABI ${RUNTIME_ABI}.`;
    } else if (manifest.runtime.react !== REACT_VERSION) {
      compatibilityCode = 'INCOMPATIBLE_REACT';
      compatibilityReason = `React version ${String(manifest.runtime.react)} is incompatible with ${REACT_VERSION}.`;
    } else if (manifest.runtime.sdk !== SDK_VERSION) {
      compatibilityCode = 'INCOMPATIBLE_SDK';
      compatibilityReason = `SDK version ${String(manifest.runtime.sdk)} is incompatible with ${SDK_VERSION}.`;
    }
  }
  if (compatibilityReason && !allowIncompatibleRuntime) throw new ExtensionValidationError(compatibilityReason, compatibilityCode);

  if (!themeRuntime && !isSafeAssetPath(manifest.entry)) throw new ExtensionValidationError('Manifest entry must be a safe relative asset path.', 'UNSAFE_PATH');
  if (!themeRuntime && (!Array.isArray(manifest.styles) || manifest.styles.some(style => !isSafeAssetPath(style)))) {
    throw new ExtensionValidationError('Manifest styles must be safe relative asset paths.', 'UNSAFE_PATH');
  }
  if (!Array.isArray(manifest.assets) || manifest.assets.length === 0) throw new ExtensionValidationError('Manifest must inventory at least one asset.');
  if (manifest.assets.length > MAX_EXTENSION_ASSETS) throw new ExtensionValidationError(`Manifest may inventory at most ${MAX_EXTENSION_ASSETS} assets.`);
  const byPath = new Map();
  let totalSize = 0;
  for (const [index, asset] of manifest.assets.entries()) {
    if (!isRecord(asset) || !isSafeAssetPath(asset.path)) throw new ExtensionValidationError(`Asset ${index} has an unsafe path.`, 'UNSAFE_PATH');
    if (!/^[a-f0-9]{64}$/.test(asset.sha256)) throw new ExtensionValidationError(`Asset '${asset.path}' must have a lowercase SHA-256 digest.`);
    if (!Number.isSafeInteger(asset.size) || asset.size < 0) throw new ExtensionValidationError(`Asset '${asset.path}' has an invalid size.`);
    if (asset.size > MAX_EXTENSION_ASSET_SIZE) throw new ExtensionValidationError(`Asset '${asset.path}' exceeds the ${MAX_EXTENSION_ASSET_SIZE}-byte limit.`);
    totalSize += asset.size;
    if (totalSize > MAX_EXTENSION_TOTAL_SIZE) throw new ExtensionValidationError(`Extension assets exceed the ${MAX_EXTENSION_TOTAL_SIZE}-byte total limit.`);
    if (byPath.has(asset.path)) throw new ExtensionValidationError(`Asset '${asset.path}' is listed more than once.`);
    byPath.set(asset.path, asset);
  }
  if (manifest.schemaVersion === 2) {
    try {
      validatePackageBackend(manifest.backend, manifest.assets);
      if (manifest.backend.workflows.some(item => item.path === manifest.entry || manifest.styles.includes(item.path))) throw new ExtensionValidationError('Workflow JSON assets must be inert and cannot be entry or style assets.');
    }
    catch (error) { throw new ExtensionValidationError(error.message, error.code ?? 'INVALID_PACKAGE_REQUIREMENTS'); }
  }
  if (!themeRuntime && !byPath.has(manifest.entry)) throw new ExtensionValidationError('Entry must be present in the asset inventory.');
  for (const style of manifest.styles ?? []) if (!byPath.has(style)) throw new ExtensionValidationError(`Style '${style}' must be present in the asset inventory.`);

  if (!Array.isArray(manifest.contributions) || manifest.contributions.length === 0) {
    throw new ExtensionValidationError('Manifest must declare at least one contribution.');
  }
  if (themeRuntime && (manifest.contributions.length !== 1 || manifest.contributions[0]?.kind !== 'theme')) throw new ExtensionValidationError('Declarative themes must contain exactly one theme contribution.');
  const contributionIds = new Set();
  for (const [index, contribution] of manifest.contributions.entries()) {
    if (!isRecord(contribution)) throw new ExtensionValidationError(`Contribution ${index} must be an object.`);
    requireString(contribution.id, `contributions[${index}].id`, 180);
    requireString(contribution.title, `contributions[${index}].title`, 200);
    if (!(themeRuntime ? ['theme'] : ['widget', 'app', 'template', 'provider']).includes(contribution.kind)) {
      throw new ExtensionValidationError(`Contribution '${contribution.id}' has an unsupported kind.`);
    }
    requireString(contribution.export, `contributions[${index}].export`, 160);
    if (contributionIds.has(contribution.id)) throw new ExtensionValidationError(`Contribution '${contribution.id}' is declared more than once.`);
    contributionIds.add(contribution.id);
    if (contribution.kind === 'template' || contribution.kind === 'theme') {
      if (!isSafeAssetPath(contribution.export) || !byPath.has(contribution.export)) {
        throw new ExtensionValidationError(`Template '${contribution.id}' must reference an inventoried JSON asset.`, 'UNSAFE_PATH');
      }
      if (!contribution.export.toLowerCase().endsWith('.json')) throw new ExtensionValidationError(`Template '${contribution.id}' must reference a JSON asset.`);
    } else if (!/^[A-Za-z_$][A-Za-z0-9_$]*$/.test(contribution.export)) {
      throw new ExtensionValidationError(`Contribution '${contribution.id}' export must be an identifier.`);
    }
    if (contribution.kind === 'app') requireString(contribution.applicationId, `contributions[${index}].applicationId`, 180);
    if (contribution.configurationSchema !== undefined) validateJsonValue(contribution.configurationSchema, `contributions[${index}].configurationSchema`);
    for (const portField of ['inputPorts', 'outputPorts']) {
      if (contribution[portField] !== undefined && !isRecord(contribution[portField])) {
        throw new ExtensionValidationError(`Contribution '${contribution.id}' ${portField} must be an object.`);
      }
    }
  }
  if (!Array.isArray(manifest.capabilities) || manifest.capabilities.some(item => typeof item !== 'string' || item.length > 160)) {
    throw new ExtensionValidationError('Manifest capabilities must be an array of strings.');
  }
  return {manifest, assetsByPath: byPath, compatibility: {available: !compatibilityReason, reason: compatibilityReason}};
}

async function readContainedRegularFile(root, relativePath, expectedSize) {
  const rootPath = path.resolve(root);
  const absolutePath = path.resolve(rootPath, ...relativePath.split('/'));
  const relation = path.relative(rootPath, absolutePath);
  if (relation === '..' || relation.startsWith(`..${path.sep}`) || path.isAbsolute(relation)) {
    throw new ExtensionValidationError(`Asset '${relativePath}' escapes the package directory.`, 'UNSAFE_PATH');
  }
  let cursor = rootPath;
  for (const part of relativePath.split('/')) {
    cursor = path.join(cursor, part);
    const stat = await lstat(cursor);
    if (stat.isSymbolicLink()) throw new ExtensionValidationError(`Asset '${relativePath}' cannot contain a symbolic link.`, 'UNSAFE_PATH');
  }
  const stat = await lstat(absolutePath);
  if (!stat.isFile()) throw new ExtensionValidationError(`Asset '${relativePath}' is not a regular file.`);
  const maxSize = expectedSize ?? 5 * 1024 * 1024;
  if (stat.size > maxSize || (expectedSize !== undefined && stat.size !== expectedSize)) {
    throw new ExtensionValidationError(`Asset '${relativePath}' has an unexpected size.`, 'ASSET_INTEGRITY');
  }
  return readFile(absolutePath);
}

export async function inspectExtensionDirectory(sourceDir) {
  const manifestBytes = await readContainedRegularFile(sourceDir, 'manifest.json');
  let manifest;
  try { manifest = JSON.parse(manifestBytes.toString('utf8')); }
  catch { throw new ExtensionValidationError('manifest.json is not valid JSON.'); }
  const {assetsByPath} = validateExtensionManifest(manifest);
  if (manifest.id.length + manifest.version.length + 1 > 128) throw new ExtensionValidationError('Extension id and version are too long for an OCI layout reference.');
  const assets = new Map();
  for (const [assetPath, expected] of [...assetsByPath.entries()].sort(([a], [b]) => a.localeCompare(b))) {
    const bytes = await readContainedRegularFile(sourceDir, assetPath, expected.size);
    if (bytes.byteLength !== expected.size) throw new ExtensionValidationError(`Asset '${assetPath}' has the wrong size.`, 'ASSET_INTEGRITY');
    if (sha256(bytes) !== expected.sha256) throw new ExtensionValidationError(`Asset '${assetPath}' failed SHA-256 verification.`, 'ASSET_INTEGRITY');
    if (manifest.contributions.some(contribution => ['template', 'theme'].includes(contribution.kind) && contribution.export === assetPath)) {
      try { const parsed = JSON.parse(bytes.toString('utf8')); if (manifest.runtime.kind === 'declarative-theme') validateTheme(parsed); }
      catch { throw new ExtensionValidationError(`Declarative asset '${assetPath}' is invalid.`); }
    }
    assets.set(assetPath, bytes);
  }
  assertAssetBytes(manifest, assets);
  return {manifest, manifestBytes, assets};
}

export function assertAssetBytes(manifest, assets, {allowIncompatibleRuntime = false} = {}) {
  const {assetsByPath, compatibility} = validateExtensionManifest(manifest, {allowIncompatibleRuntime});
  if (!(assets instanceof Map)) throw new ExtensionValidationError('Release assets must be a path-to-bytes map.');
  if (assets.size !== assetsByPath.size) throw new ExtensionValidationError('Release contains missing or unlisted assets.', 'ASSET_INTEGRITY');
  for (const [assetPath, expected] of assetsByPath) {
    const bytes = assets.get(assetPath);
    if (!Buffer.isBuffer(bytes) && !(bytes instanceof Uint8Array)) throw new ExtensionValidationError(`Release asset '${assetPath}' is missing.`, 'ASSET_INTEGRITY');
    if (bytes.byteLength !== expected.size || sha256(bytes) !== expected.sha256) {
      throw new ExtensionValidationError(`Release asset '${assetPath}' failed integrity verification.`, 'ASSET_INTEGRITY');
    }
  }
  for (const contribution of manifest.contributions) {
    if (contribution.kind === 'theme') {
      try { validateTheme(JSON.parse(new TextDecoder('utf-8', {fatal: true}).decode(assets.get(contribution.export)))); }
      catch { throw new ExtensionValidationError(`Declarative asset '${contribution.export}' is invalid.`); }
    }
    if (contribution.kind === 'template') {
      let template;
      try { template=JSON.parse(manifest.schemaVersion===2 ? new TextDecoder('utf-8',{fatal:true}).decode(assets.get(contribution.export)) : Buffer.from(assets.get(contribution.export)).toString('utf8')); }
      catch { throw new ExtensionValidationError(`Template asset '${contribution.export}' is not valid JSON.`); }
      // A strict package's inline recipes are requirement assets too. Listing
      // only a different, valid standalone recipe must not bypass declaration.
      if (manifest.schemaVersion===2 && (![1,2].includes(template?.schemaVersion) || (template.schemaVersion===1 && Object.hasOwn(template,'backend')))) throw new ExtensionValidationError('Portable template version is unsupported.','INVALID_PACKAGE_REQUIREMENTS');
      if (manifest.schemaVersion===2 && template.schemaVersion===2) {
        if (!template.backend || template.backend.schemaVersion!==1 || !Array.isArray(template.backend.workflows) || template.backend.workflows.length>200) throw new ExtensionValidationError('Portable template backend is unsupported.','INVALID_PACKAGE_REQUIREMENTS');
        for (const workflow of template.backend.workflows) {
          try { validateDeclaredWorkflow(workflow?.definition,manifest.backend); }
          catch (error) { throw new ExtensionValidationError(error.message,'INVALID_PACKAGE_REQUIREMENTS'); }
        }
      }
    }
  }
  if (manifest.schemaVersion === 2) {
    try { validatePackageWorkflowAssets(manifest.backend, assets); }
    catch (error) { throw new ExtensionValidationError(error.message, error.code ?? 'INVALID_PACKAGE_REQUIREMENTS'); }
  }
  return compatibility;
}
