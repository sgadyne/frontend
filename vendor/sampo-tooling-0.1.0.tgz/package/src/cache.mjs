import {mkdir, readFile, lstat, rename, rm, stat, writeFile} from 'node:fs/promises';
import path from 'node:path';
import {
  assertAssetBytes, EXTENSION_ARTIFACT_TYPE, EXTENSION_CONFIG_MEDIA_TYPE,
  OCI_CONFIG_MEDIA_TYPE, OCI_LAYER_MEDIA_TYPE, OCI_MANIFEST_MEDIA_TYPE,
  ExtensionValidationError, isSafeAssetPath, sha256, validateExtensionManifest,
} from './extension.mjs';
import {readOciExtension} from './oci-layout.mjs';
import {acquireRuntimeWriter} from './runtime-store.mjs';

const DIGEST_PATTERN = /^sha256:[a-f0-9]{64}$/;
const catalogLocks = new Map();

function extensionDir(runtimeDir, digest) {
  if (!DIGEST_PATTERN.test(digest)) throw new ExtensionValidationError('Extension digest is invalid.', 'INVALID_DIGEST');
  return path.join(path.resolve(runtimeDir), 'extensions', digest.slice(7));
}

async function readCachedRelease(runtimeDir, digest, {verifyAssets = false} = {}) {
  const root = extensionDir(runtimeDir, digest);
  try {
    const parentInfo = await lstat(path.dirname(root));
    const rootInfo = await lstat(root);
    if (parentInfo.isSymbolicLink() || rootInfo.isSymbolicLink() || !rootInfo.isDirectory()) {
      throw new ExtensionValidationError('Extension cache paths must be regular directories.', 'UNSAFE_PATH');
    }
  } catch (error) {
    if (error.code === 'ENOENT') throw new ExtensionValidationError(`Extension release '${digest}' is not cached.`, 'RELEASE_NOT_FOUND');
    throw error;
  }
  let ociManifestBytes;
  const manifestPath = path.join(root, 'oci-manifest.json');
  let manifestInfo;
  try { manifestInfo = await stat(manifestPath); }
  catch (error) {
    if (error.code === 'ENOENT') throw new ExtensionValidationError(`Extension release '${digest}' is not cached.`, 'RELEASE_NOT_FOUND');
    throw error;
  }
  if (manifestInfo.size > 2 * 1024 * 1024) throw new ExtensionValidationError('Cached OCI manifest exceeds its size limit.', 'INVALID_OCI_LAYOUT');
  ociManifestBytes = await readFile(manifestPath);
  if (`sha256:${sha256(ociManifestBytes)}` !== digest) throw new ExtensionValidationError('Cached OCI manifest failed digest verification.', 'ASSET_INTEGRITY');
  let artifact;
  try { artifact = JSON.parse(ociManifestBytes.toString('utf8')); }
  catch { throw new ExtensionValidationError('Cached OCI manifest is invalid JSON.', 'INVALID_OCI_LAYOUT'); }
  if (artifact.schemaVersion !== 2 || artifact.mediaType !== OCI_MANIFEST_MEDIA_TYPE || artifact.artifactType !== EXTENSION_ARTIFACT_TYPE || !Array.isArray(artifact.layers)) {
    throw new ExtensionValidationError('Cached artifact is not a supported extension.', 'INCOMPATIBLE_RUNTIME');
  }
  if (artifact.config?.mediaType !== OCI_CONFIG_MEDIA_TYPE || !DIGEST_PATTERN.test(artifact.config.digest)) {
    throw new ExtensionValidationError('Cached extension config descriptor is invalid.', 'INVALID_OCI_LAYOUT');
  }
  let configBytes;
  const configPath = path.join(root, 'oci-config.json');
  let configInfo;
  try { configInfo = await stat(configPath); }
  catch (error) {
    if (error.code === 'ENOENT') throw new ExtensionValidationError('Cached extension config is missing.', 'ASSET_INTEGRITY');
    throw error;
  }
  if (configInfo.size > 5 * 1024 * 1024) throw new ExtensionValidationError('Cached extension config exceeds its size limit.', 'INVALID_OCI_LAYOUT');
  configBytes = await readFile(configPath);
  if (configBytes.byteLength !== artifact.config.size || `sha256:${sha256(configBytes)}` !== artifact.config.digest) {
    throw new ExtensionValidationError('Cached extension config failed integrity verification.', 'ASSET_INTEGRITY');
  }
  let config;
  try { config = JSON.parse(configBytes.toString('utf8')); }
  catch { throw new ExtensionValidationError('Cached extension config is invalid JSON.', 'INVALID_OCI_LAYOUT'); }
  if (config.mediaType !== EXTENSION_CONFIG_MEDIA_TYPE) throw new ExtensionValidationError('Cached extension config media type is invalid.', 'INVALID_OCI_LAYOUT');
  const {manifest, assetsByPath} = validateExtensionManifest(config.manifest);
  const layers = new Map();
  for (const layer of artifact.layers) {
    const assetPath = layer.annotations?.['org.opencontainers.image.title'];
    if (layer.mediaType !== OCI_LAYER_MEDIA_TYPE || !isSafeAssetPath(assetPath) || layers.has(assetPath) || !DIGEST_PATTERN.test(layer.digest)) {
      throw new ExtensionValidationError('Cached extension layer metadata is invalid.', 'INVALID_OCI_LAYOUT');
    }
    const expected = assetsByPath.get(assetPath);
    if (!expected || layer.size !== expected.size || layer.digest !== `sha256:${expected.sha256}`) {
      throw new ExtensionValidationError(`Cached extension layer '${assetPath}' does not match its manifest.`, 'ASSET_INTEGRITY');
    }
    layers.set(assetPath, layer);
  }
  if (layers.size !== assetsByPath.size) throw new ExtensionValidationError('Cached extension is missing inventoried layers.', 'ASSET_INTEGRITY');

  const assets = new Map();
  for (const assetPath of assetsByPath.keys()) {
    if (!verifyAssets) continue;
    const layer = layers.get(assetPath);
    const bytes = await readCachedAssetFile(root, assetPath, layer.size);
    if (bytes.byteLength !== layer.size || `sha256:${sha256(bytes)}` !== layer.digest) {
      throw new ExtensionValidationError(`Cached extension asset '${assetPath}' failed integrity verification.`, 'ASSET_INTEGRITY');
    }
    assets.set(assetPath, bytes);
  }
  if (verifyAssets) assertAssetBytes(manifest, assets);
  return {root, digest, manifest, artifact, ociManifestBytes, configBytes, layers, assetsByPath, assets};
}

async function readCachedAssetFile(root, assetPath, expectedSize) {
  if (!isSafeAssetPath(assetPath)) throw new ExtensionValidationError('Requested extension asset path is unsafe.', 'UNSAFE_PATH');
  const absolute = path.resolve(root, ...assetPath.split('/'));
  const relation = path.relative(root, absolute);
  if (relation === '..' || relation.startsWith(`..${path.sep}`) || path.isAbsolute(relation)) {
    throw new ExtensionValidationError('Requested extension asset escapes the cache.', 'UNSAFE_PATH');
  }
  let current = root;
  for (const part of assetPath.split('/')) {
    current = path.join(current, part);
    const entry = await lstat(current);
    if (entry.isSymbolicLink()) throw new ExtensionValidationError('Cached extension assets cannot be symbolic links.', 'UNSAFE_PATH');
  }
  const entry = await lstat(absolute);
  if (!entry.isFile()) throw new ExtensionValidationError('Cached extension asset is not a regular file.', 'ASSET_INTEGRITY');
  if (entry.size > 50 * 1024 * 1024 || (expectedSize !== undefined && entry.size !== expectedSize)) {
    throw new ExtensionValidationError('Cached extension asset has an unexpected size.', 'ASSET_INTEGRITY');
  }
  return readFile(absolute);
}

async function writeAtomic(filename, bytes) {
  await mkdir(path.dirname(filename), {recursive: true});
  const temporary = `${filename}.${process.pid}.${Date.now()}.tmp`;
  await writeFile(temporary, bytes, {flag: 'wx'});
  try { await rename(temporary, filename); }
  catch (error) { await rm(temporary, {force: true}); throw error; }
}

async function updateCatalog(runtimeDir, mutate) {
  const catalogPath = path.join(path.resolve(runtimeDir), 'catalog.json');
  const previous = catalogLocks.get(catalogPath) ?? Promise.resolve();
  const next = previous.then(async () => {
    let catalog = {schemaVersion: 1, entries: []};
    try {
      catalog = JSON.parse((await readFile(catalogPath, 'utf8')));
      if (catalog.schemaVersion !== 1 || !Array.isArray(catalog.entries)) throw new Error('schema mismatch');
    } catch (error) {
      if (error.code !== 'ENOENT') throw new ExtensionValidationError(`Local catalog is invalid: ${error.message}`, 'INVALID_CATALOG');
    }
    const updated = mutate(catalog);
    await writeAtomic(catalogPath, Buffer.from(JSON.stringify(updated, null, 2)));
    return updated;
  });
  const queued = next.catch(() => {});
  catalogLocks.set(catalogPath, queued);
  try { return await next; }
  finally { if (catalogLocks.get(catalogPath) === queued) catalogLocks.delete(catalogPath); }
}

function makeCatalogEntry(manifest, digest, {availability, reason} = {}) {
  const contribution = manifest.contributions[0];
  return {
    id: manifest.id,
    title: contribution.title,
    description: contribution.description ?? '',
    version: manifest.version,
    publisher: manifest.publisher,
    license: manifest.license,
    digest,
    source: 'oci-layout',
    contributions: manifest.contributions,
    availability,
    ...(reason ? {reason} : {}),
  };
}

async function assertUnmanagedRuntime(runtimeDir) {
  const root = path.resolve(runtimeDir ?? '.runtime');
  const communityDir = path.join(root, 'community');
  try {
    const info = await lstat(communityDir);
    if (info.isSymbolicLink() || !info.isDirectory()) {
      throw new ExtensionValidationError('Community-managed runtime paths must be regular directories; legacy activation is disabled.', 'MANAGED_RUNTIME');
    }
  } catch (error) {
    if (error.code !== 'ENOENT') throw error;
  }
  for (const marker of [path.join(root, 'community-managed.json'), path.join(communityDir, 'authority.json')]) {
    try {
      await lstat(marker);
      throw new ExtensionValidationError('This runtime has community authority state; use the guarded community stage, approval and install API instead of legacy activate.', 'MANAGED_RUNTIME');
    } catch (error) {
      if (error.code !== 'ENOENT') throw error;
    }
  }
}

export async function activateOciExtension({layoutDir, digest, runtimeDir, windowsLoopbackDev = false}) {
  const writerLease = await acquireRuntimeWriter(runtimeDir ?? '.runtime', {windowsLoopbackDev});
  runtimeDir = writerLease.runtimeDir;
  try {
    writerLease.assertHeld();
    await assertUnmanagedRuntime(runtimeDir);
    const release = await readOciExtension(layoutDir, digest);
    writerLease.assertHeld();
    if (!release.compatibility.available) {
      await assertUnmanagedRuntime(runtimeDir);
      const catalogEntry = makeCatalogEntry(release.manifest, digest, {availability: 'unavailable', reason: release.compatibility.reason});
      writerLease.assertHeld();
      await updateCatalog(runtimeDir, catalog => {
        const entries = catalog.entries.filter(item => item.digest !== digest);
        entries.push(catalogEntry);
        entries.sort((left, right) => left.id.localeCompare(right.id) || left.version.localeCompare(right.version));
        return {schemaVersion: 1, entries};
      });
      return {digest, availability: 'unavailable', catalogEntry};
    }
    const root = extensionDir(runtimeDir, digest);
    await assertUnmanagedRuntime(runtimeDir);
    writerLease.assertHeld();
    await mkdir(path.dirname(root), {recursive: true});
    try {
      await readCachedRelease(runtimeDir, digest, {verifyAssets: true});
      const existingManifest = await readFile(path.join(root, 'oci-manifest.json'));
      if (!existingManifest.equals(release.ociManifestBytes)) throw new ExtensionValidationError('An immutable release cache entry already exists with different content.', 'IMMUTABLE_CACHE');
    } catch (error) {
      if (error.code !== 'RELEASE_NOT_FOUND') throw error;
      try {
        await lstat(root);
        throw new ExtensionValidationError('An incomplete cache entry already exists for this immutable digest.', 'IMMUTABLE_CACHE');
      } catch (statError) {
        if (statError.code !== 'ENOENT') throw statError;
      }
      const stage = `${root}.stage-${process.pid}-${Date.now()}`;
      await mkdir(stage, {recursive: true});
      try {
        await writeFile(path.join(stage, 'oci-manifest.json'), release.ociManifestBytes);
        await writeFile(path.join(stage, 'oci-config.json'), release.ociConfigBytes);
        for (const [assetPath, bytes] of release.assets) {
          const target = path.join(stage, ...assetPath.split('/'));
          await mkdir(path.dirname(target), {recursive: true});
          await writeFile(target, bytes, {flag: 'wx'});
        }
        await rename(stage, root);
      } catch (writeError) {
        await rm(stage, {recursive: true, force: true});
        throw writeError;
      }
      await readCachedRelease(runtimeDir, digest, {verifyAssets: true});
    }

    const entry = makeCatalogEntry(release.manifest, digest, {availability: 'installed'});
    await assertUnmanagedRuntime(runtimeDir);
    writerLease.assertHeld();
    await updateCatalog(runtimeDir, catalog => {
      const key = candidate => candidate.digest === digest;
      const entries = catalog.entries.filter(item => !key(item));
      entries.push(entry);
      entries.sort((left, right) => left.id.localeCompare(right.id) || left.version.localeCompare(right.version));
      return {schemaVersion: 1, entries};
    });
    return {digest, cacheDir: root, catalogEntry: entry};
  } finally {
    await writerLease.release();
  }
}

export async function readLocalCatalog(runtimeDir) {
  try {
    const catalog = JSON.parse(await readFile(path.join(path.resolve(runtimeDir), 'catalog.json'), 'utf8'));
    if (catalog.schemaVersion !== 1 || !Array.isArray(catalog.entries)) throw new Error('schema mismatch');
    return catalog.entries;
  } catch (error) {
    if (error.code === 'ENOENT') return [];
    throw new ExtensionValidationError(`Local catalog is invalid: ${error.message}`, 'INVALID_CATALOG');
  }
}

export async function readCachedExtensionAsset(runtimeDir, digest, assetPath) {
  const release = await readCachedRelease(runtimeDir, digest);
  if (!isSafeAssetPath(assetPath)) throw new ExtensionValidationError('Requested extension asset path is unsafe.', 'UNSAFE_PATH');
  const expected = release.assetsByPath.get(assetPath);
  const layer = release.layers.get(assetPath);
  if (!expected || !layer) throw new ExtensionValidationError('Extension asset was not inventoried.', 'ASSET_NOT_FOUND');
  const bytes = await readCachedAssetFile(release.root, assetPath, expected.size);
  if (bytes.byteLength !== expected.size || `sha256:${sha256(bytes)}` !== layer.digest) {
    throw new ExtensionValidationError(`Cached extension asset '${assetPath}' failed integrity verification.`, 'ASSET_INTEGRITY');
  }
  return {bytes, manifest: release.manifest, asset: expected};
}

export async function readCachedExtensionDescriptor(runtimeDir, digest) {
  const release = await readCachedRelease(runtimeDir, digest, {verifyAssets: true});
  return {
    digest,
    manifest: release.manifest,
    assetBaseUrl: `/extensions/sha256-${digest.slice(7)}/`,
  };
}
