const semanticTokenKeys = ['color.primary','color.background','color.surface','color.text','color.text.muted','color.border','color.focus','typography.family','typography.size','shape.control.radius','control.height','control.density'];
const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
export function validateTokenMap(value) {
  if (!object(value) || Object.keys(value).length > semanticTokenKeys.length) throw new TypeError('Invalid semantic token map');
  for (const [key, token] of Object.entries(value)) {
    if (!semanticTokenKeys.includes(key) || typeof token !== 'string' || !token.trim() || token.length > 200 || /[;{}\\\x00-\x1f]/.test(token) || /(?:url|expression|var)\s*\(/i.test(token)) throw new TypeError(`Invalid semantic token ${key}`);
    if (key === 'control.density' && !['compact', 'comfortable'].includes(token)) throw new TypeError('Invalid density');
  }
  return value;
}
export function validateTheme(value) {
  if (!object(value) || Object.keys(value).some(key => !['schemaVersion','tokens','variants','density','typography'].includes(key)) || value.schemaVersion !== 1 || !['compact','comfortable'].includes(value.density) || !object(value.typography) || Object.keys(value.typography).some(key => key !== 'family') || typeof value.typography.family !== 'string') throw new TypeError('Invalid theme');
  validateTokenMap(value.tokens); validateTokenMap({'typography.family': value.typography.family});
  if (!object(value.variants) || Object.keys(value.variants).some(key => !['light','dark'].includes(key))) throw new TypeError('Invalid variants');
  validateTokenMap(value.variants.light); validateTokenMap(value.variants.dark);
  return value;
}
