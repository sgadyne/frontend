export interface Theme {schemaVersion: 1; tokens: Record<string, string>; variants: {light: Record<string, string>; dark: Record<string, string>}; density: 'compact' | 'comfortable'; typography: {family: string}}
export function validateTokenMap(value: unknown): Record<string, string>;
export function validateTheme(value: unknown): Theme;
